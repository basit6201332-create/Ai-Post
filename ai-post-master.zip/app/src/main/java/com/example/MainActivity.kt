package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.db.CategoryEntity
import com.example.data.db.PostEntity
import com.example.data.firebase.FirebaseManager
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PostViewModel
import com.example.ui.viewmodel.PostViewModelFactory
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as UrduPostWriterApp
        val factory = PostViewModelFactory(app.repository)
        val viewModel: PostViewModel by viewModels { factory }

        setContent {
            MyApplicationTheme {
                val currentUser by viewModel.currentUser.collectAsState()
                val context = androidx.compose.ui.platform.LocalContext.current
                androidx.compose.runtime.LaunchedEffect(currentUser) {
                    currentUser?.let {
                        viewModel.syncFacebookCredentials(context)
                    }
                }
                var isBypassed by remember { mutableStateOf(false) }
                val isResearchingAndWriting by viewModel.isResearchingAndWriting.collectAsState()

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    if (currentUser == null && !isBypassed) {
                        AuthScreen(
                            viewModel = viewModel,
                            onBypass = { isBypassed = true },
                            modifier = Modifier.padding(innerPadding)
                        )
                    } else {
                        MainScreen(
                            viewModel = viewModel,
                            onSignOut = {
                                viewModel.signOut()
                                isBypassed = false
                            },
                            modifier = Modifier.padding(innerPadding)
                        )
                    }
                }
            }
        }
    }
}

fun getWebClientId(context: Context): String? {
    try {
        val value = BuildConfig.GOOGLE_WEB_CLIENT_ID
        if (!value.isNullOrBlank() && value != "YOUR_GOOGLE_WEB_CLIENT_ID") {
            return value
        }
    } catch (e: Exception) {
        // Ignore
    }

    try {
        val resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
        if (resId != 0) {
            val value = context.getString(resId)
            if (!value.isNullOrBlank()) {
                return value
            }
        }
    } catch (e: Exception) {
        // Ignore
    }
    return null
}

/**
 * Authentic Social Media Urdu Post Writer - Authentication Screen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: PostViewModel,
    onBypass: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(false) }

    val isAuthLoading by viewModel.isAuthLoading.collectAsState()
    val authError by viewModel.authError.collectAsState()

    // Google Sign-In setup
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                val idToken = account.idToken
                if (idToken != null) {
                    val credential = GoogleAuthProvider.getCredential(idToken, null)
                    viewModel.signInWithGoogleCredential(credential) { success ->
                        if (success) {
                            Toast.makeText(context, "گوگل سے کامیابی کے ساتھ لاگ ان ہو گیا!", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    viewModel.signInWithGoogleFallback { success ->
                        if (success) {
                            Toast.makeText(context, "گوگل بائی پاس کے ساتھ لاگ ان ہو گیا!", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("AuthScreen", "Google sign in failed, falling back: ${e.message}")
                viewModel.signInWithGoogleFallback { success ->
                    if (success) {
                        Toast.makeText(context, "گوگل بائی پاس کے ساتھ لاگ ان ہو گیا!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        } else {
            viewModel.signInWithGoogleFallback { success ->
                if (success) {
                    Toast.makeText(context, "گوگل بائی پاس کے ساتھ لاگ ان ہو گیا!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.background
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp)
                .testTag("auth_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "✍️",
                    fontSize = 48.sp
                )
                Text(
                    text = if (isSignUp) "نیا اکاؤنٹ بنائیں (Register)" else "لاگ ان کریں (Sign In)",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "اردو ریسرچ اور پوسٹ تحریر کار",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                if (authError != null) {
                    Text(
                        text = authError!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                // Inputs
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("ای میل ایڈریس (Email)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("email_input"),
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = "Email") }
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("پاس ورڈ (Password)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("password_input"),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = "Password") },
                    visualTransformation = PasswordVisualTransformation()
                )

                // Main Authentication Action Button
                Button(
                    onClick = {
                        if (isSignUp) {
                            viewModel.signUpWithEmail(email.trim(), password.trim()) { success ->
                                if (success) {
                                    Toast.makeText(context, "اکاؤنٹ کامیابی سے بن گیا!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            viewModel.signInWithEmail(email.trim(), password.trim()) { success ->
                                if (success) {
                                    Toast.makeText(context, "خوش آمدید!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("auth_action_btn"),
                    enabled = !isAuthLoading && email.isNotBlank() && password.isNotBlank()
                ) {
                    if (isAuthLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Text(if (isSignUp) "سائن اپ کریں" else "لاگ ان کریں", fontWeight = FontWeight.Bold)
                    }
                }

                // Toggle Sign In / Sign Up modes
                TextButton(
                    onClick = { isSignUp = !isSignUp },
                    enabled = !isAuthLoading
                ) {
                    Text(
                        text = if (isSignUp) "پہلے سے اکاؤنٹ ہے؟ لاگ ان کریں" else "نیا اکاؤنٹ بنانا چاہتے ہیں؟ سائن اپ کریں",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 4.dp))

                // Google Sign In integration
                Button(
                    onClick = {
                        val clientId = getWebClientId(context)
                        if (clientId == null) {
                            Toast.makeText(context, "گوگل لاگ ان کے لیے Web Client ID کنفیگر نہیں ہے۔ براہ کرم اسے فائر بیس یا سیکریٹس میں درج کریں!", Toast.LENGTH_LONG).show()
                        }
                        val finalClientId = clientId ?: "your-placeholder-client-id.apps.googleusercontent.com"
                        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                            .requestIdToken(finalClientId)
                            .requestEmail()
                            .build()
                        val googleSignInClient = GoogleSignIn.getClient(context, gso)
                        googleSignInLauncher.launch(googleSignInClient.signInIntent)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF4285F4),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("google_signin_btn"),
                    enabled = !isAuthLoading
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBox,
                            contentDescription = "Google Icon",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("گوگل سے سائن ان کریں (Google)", fontWeight = FontWeight.Bold)
                    }
                }

                // Bypass/Offline Continuation Options
                OutlinedButton(
                    onClick = onBypass,
                    modifier = Modifier.fillMaxWidth().testTag("bypass_auth_btn"),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.secondary
                    )
                ) {
                    Text("بغیر لاگ ان کے آگے بڑھیں (گیسٹ موڈ)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Stylish Orbiting Solar/Celestial Particle Animation Rendered in Canvas
 */
@Composable
fun SpaceOrbitLoaderAnimation() {
    val infiniteTransition = rememberInfiniteTransition(label = "orbits")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier.size(220.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)

            // 1. Draw central glowing nebula
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF00FFCC).copy(alpha = 0.35f * pulseScale), Color.Transparent),
                    center = center,
                    radius = 95.dp.toPx()
                ),
                radius = 95.dp.toPx()
            )

            // 2. Core Sphere (Glow)
            drawCircle(
                color = Color(0xFF00FFCC),
                radius = 22.dp.toPx() * (0.92f + pulseScale * 0.08f),
                center = center
            )
            // Core Border
            drawCircle(
                color = Color.White.copy(alpha = 0.8f),
                radius = 12.dp.toPx(),
                center = center
            )

            // 3. First Orbit Path (Inner)
            drawCircle(
                color = Color(0xFF00FFCC).copy(alpha = 0.25f),
                radius = 55.dp.toPx(),
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // 4. Second Orbit Path (Middle)
            drawCircle(
                color = Color(0xFF9933FF).copy(alpha = 0.2f),
                radius = 80.dp.toPx(),
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // 5. Orbiting Satellites
            // Inner Satellite
            val angle1Rad = Math.toRadians(rotationAngle.toDouble())
            val sat1X = center.x + 55.dp.toPx() * cos(angle1Rad).toFloat()
            val sat1Y = center.y + 55.dp.toPx() * sin(angle1Rad).toFloat()
            drawCircle(
                color = Color(0xFF00FFCC),
                radius = 5.dp.toPx(),
                center = Offset(sat1X, sat1Y)
            )

            // Outer Satellite (Offset rotation speed or angle)
            val angle2Rad = Math.toRadians((rotationAngle + 135).toDouble())
            val sat2X = center.x + 80.dp.toPx() * cos(angle2Rad).toFloat()
            val sat2Y = center.y + 80.dp.toPx() * sin(angle2Rad).toFloat()
            drawCircle(
                color = Color(0xFF9933FF),
                radius = 7.dp.toPx(),
                center = Offset(sat2X, sat2Y)
            )

            // Outer Orbit Path (Large Accent)
            drawCircle(
                color = Color(0xFFFFCC00).copy(alpha = 0.15f),
                radius = 100.dp.toPx(),
                center = center,
                style = Stroke(width = 1.dp.toPx())
            )
            // Large Satellite
            val angle3Rad = Math.toRadians((rotationAngle * 0.8 - 60).toDouble())
            val sat3X = center.x + 100.dp.toPx() * cos(angle3Rad).toFloat()
            val sat3Y = center.y + 100.dp.toPx() * sin(angle3Rad).toFloat()
            drawCircle(
                color = Color(0xFFFFCC00),
                radius = 4.dp.toPx(),
                center = Offset(sat3X, sat3Y)
            )
        }
    }
}

/**
 * Full Screen Premium Research Loading Overlay
 */
@Composable
fun ResearchLoadingScreen(
    viewModel: PostViewModel,
    modifier: Modifier = Modifier
) {
    val researchLogs by viewModel.researchLogs.collectAsState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A)) // Slate-900 cosmic dark background
            .testTag("research_screen_loading"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // High-Tech Solar Orbit Loader
            SpaceOrbitLoaderAnimation()

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = "ڈیپ ریسرچ اور تحریر جاری ہے...",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF00FFCC),
                    letterSpacing = 0.5.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Current Step Display Card
            val currentStatus = researchLogs.lastOrNull() ?: "کلاؤڈ کمپیوٹنگ ریسرچ شروع کی جا رہی ہے..."
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF1E293B)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF334155)),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .testTag("current_step_card")
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = currentStatus,
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF1F5F9)
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            if (researchLogs.size > 1) {
                Spacer(modifier = Modifier.height(24.dp))
                // Beautifully Faded Log History List
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.alpha(0.55f)
                ) {
                    researchLogs.dropLast(1).takeLast(3).forEach { log ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Done",
                                tint = Color(0xFF00FFCC).copy(alpha = 0.7f),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = log,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color(0xFF94A3B8)
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Main Application Dashboard Screen
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: PostViewModel,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf("Home") }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == "Home",
                    onClick = { selectedTab = "Home" },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = selectedTab == "Brainstorm",
                    onClick = { selectedTab = "Brainstorm" },
                    icon = { Icon(Icons.Default.Edit, contentDescription = "Brainstorm") },
                    label = { Text("Brainstorm") },
                    modifier = Modifier.testTag("nav_brainstorm")
                )
                NavigationBarItem(
                    selected = selectedTab == "Drafts",
                    onClick = { selectedTab = "Drafts" },
                    icon = { Icon(Icons.Default.Info, contentDescription = "Drafts") },
                    label = { Text("Drafts") },
                    modifier = Modifier.testTag("nav_drafts")
                )
                NavigationBarItem(
                    selected = selectedTab == "Scheduled",
                    onClick = { selectedTab = "Scheduled" },
                    icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Scheduled") },
                    label = { Text("Scheduled") },
                    modifier = Modifier.testTag("nav_scheduled")
                )
                NavigationBarItem(
                    selected = selectedTab == "Settings",
                    onClick = { selectedTab = "Settings" },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") },
                    modifier = Modifier.testTag("nav_settings")
                )
            }
        },
        modifier = modifier
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                "Home" -> HomeScreenView(viewModel, onSignOut, onNavigateToTab = { selectedTab = it })
                "Brainstorm" -> BrainstormScreenView(viewModel)
                "Drafts" -> DraftsScreenView(viewModel)
                "Scheduled" -> ScheduledScreenView(viewModel)
                "Settings" -> SettingsScreenView(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MainScreenOld(
    viewModel: PostViewModel,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    // ViewModel States
    val categories by viewModel.categories.collectAsState()
    val postsHistory by viewModel.postsHistory.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val suggestedSubCategories by viewModel.suggestedSubCategories.collectAsState()
    val selectedTopic by viewModel.selectedTopic.collectAsState()
    val generatedPost by viewModel.generatedPost.collectAsState()
    val isGeneratingTopics by viewModel.isGeneratingTopics.collectAsState()
    val isResearchingAndWriting by viewModel.isResearchingAndWriting.collectAsState()
    val imagePrompt by viewModel.imagePrompt.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    // Local UI states
    var showAddCategoryDialog by remember { mutableStateOf(false) }
    var showPostHistoryDialog by remember { mutableStateOf(false) }
    var selectedHistoryPost by remember { mutableStateOf<PostEntity?>(null) }

    LaunchedEffect(selectedHistoryPost) {
        selectedHistoryPost?.let { post ->
            viewModel.generateImagePrompt(post.content)
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // 1. Hero Banner with Image Background & Cloud Storage Indicators
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner),
                contentDescription = "AI Storytelling Writing Engine",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            // Premium Slate Gradient Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                MaterialTheme.colorScheme.background.copy(alpha = 0.98f)
                            )
                        )
                    )
            )

            // Header elements overlaid beautifully
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.binddp()),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Firebase Cloud Sync Indicator
                    if (FirebaseManager.isFirebaseInitialized) {
                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color(0xFF2E7D32), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "☁️ Firebase Synced",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }
                    } else {
                        Surface(
                            color = Color(0xFFFFF3E0),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color(0xFFE65100), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "💾 Local Vault Mode (Room Active)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFFE65100)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "اردو ریسرچ اور تحریر انجن",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Urdu Post Research & Writing Engine",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            // General Info and Action Buttons (Add Category / History Vault / Logout)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اہم کیٹیگری کا انتخاب کریں:",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    // History Vault Button
                    IconButton(
                        onClick = { showPostHistoryDialog = true },
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.secondaryContainer, CircleShape)
                            .testTag("history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = "Post History Vault",
                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }

                    // Logout Button (Urdu Post Author Identity)
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.8f), CircleShape)
                            .testTag("logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Sign Out",
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }

                    // Add Custom Category Button
                    Button(
                        onClick = { showAddCategoryDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("add_custom_category_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نیا کیٹیگری", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // User Profile details under actions
            currentUser?.let { user ->
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(8.dp).background(Color(0xFF00FFCC), CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "لاگ ان صارف: ${user.email ?: "گیسٹ"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 2. MAIN CATEGORY DASHBOARD: Beautiful pre-populated + custom categories in grid
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory?.id == category.id
                    Card(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .widthIn(min = 100.dp)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectCategory(category) }
                            .testTag("category_card_${category.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = category.icon,
                                fontSize = 18.sp
                            )
                            Column {
                                Text(
                                    text = category.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = category.englishName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // 3. SUBCATEGORIES SECTION: Gemini AI Dynamic Synthesis
            selectedCategory?.let { category ->
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("subcategories_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🧠 ${category.name} سے متعلق منتخب موضوعات:",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (isGeneratingTopics) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.primary,
                                    strokeWidth = 2.dp
                                )
                            }
                        }
                        Text(
                            text = "Gemini AI has dynamically filtered out your previously written topics to recommend 5 fresh social media titles.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                        )

                        if (isGeneratingTopics && suggestedSubCategories.isEmpty()) {
                            Text(
                                text = "تحقیق اور بہترین موضوعات کی تلاش جاری ہے...",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            // Render Suggested topics
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                suggestedSubCategories.forEach { topic ->
                                    val isTopicSelected = selectedTopic == topic
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.selectTopic(topic) }
                                            .testTag("topic_item_$topic"),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isTopicSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = topic,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = if (isTopicSelected) FontWeight.Bold else FontWeight.Medium
                                                ),
                                                color = if (isTopicSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.weight(1f),
                                                textAlign = TextAlign.End
                                            )
                                            if (isTopicSelected) {
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Icon(
                                                    imageVector = Icons.Default.Check,
                                                    contentDescription = "Selected",
                                                    tint = MaterialTheme.colorScheme.onPrimary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. RESEARCH & POST GENERATION STARTER
            if (selectedTopic.isNotEmpty()) {
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { viewModel.startResearchAndWriting() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("start_writing_button"),
                    shape = RoundedCornerShape(27.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    ),
                    enabled = !isResearchingAndWriting
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Start research",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "موضوع پر ریسرچ اور تحریر شروع کریں ✨",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 5. ERROR DISPLAY
            errorMessage?.let { err ->
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("error_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "⚠️ ریسرچ خرابی (Error)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // 6. STORY WRITING READER (The Final Generated Article)
            generatedPost?.let { post ->
                Spacer(modifier = Modifier.height(24.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generated_post_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        // Title Reader
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "تحریر کا تاریخ اور وقت",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "موضوع: $selectedTopic",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.End
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Topic",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // SelectionContainer allows user to select & copy specific parts
                        SelectionContainer {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = post,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        lineHeight = 28.sp,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Low-profile English Image Generation Prompt Section
                        ImagePromptWidget(
                            imagePrompt = imagePrompt,
                            onCopyClick = { prompt ->
                                clipboardManager.setText(AnnotatedString(prompt))
                                Toast.makeText(context, "تصویر کا پرامپٹ کاپی ہو گیا ہے!", Toast.LENGTH_SHORT).show()
                            }
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        // Fast Action Options (Urdu Labels with visual layout)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Fast Copy Button
                            Button(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(post))
                                    Toast.makeText(context, "پوسٹ کامیابی کے ساتھ کاپی کر لی گئی ہے!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("copy_post_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Edit, contentDescription = "Copy")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("کاپی کریں (Copy)", fontWeight = FontWeight.Bold)
                            }

                            // Share Option
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, post)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "تحریر شیئر کریں"))
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("share_post_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = "Share")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("شیئر کریں", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Modal/Dialog 1: Add Custom Category
    if (showAddCategoryDialog) {
        var categoryUrduName by remember { mutableStateOf("") }
        var categoryEnglishName by remember { mutableStateOf("") }
        var categoryIconEmoji by remember { mutableStateOf("⭐") }

        Dialog(onDismissRequest = { showAddCategoryDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .testTag("add_category_dialog"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "جدید حسب منشا کیٹیگری شامل کریں",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )
                    Text(
                        text = "Add a custom writing domain. It will automatically sync to your cloud backup so you never lose your workspace.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = categoryUrduName,
                        onValueChange = { categoryUrduName = it },
                        label = { Text("کیٹیگری کا اردو نام") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_urdu_name_input")
                    )

                    OutlinedTextField(
                        value = categoryEnglishName,
                        onValueChange = { categoryEnglishName = it },
                        label = { Text("Category English Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_english_name_input")
                    )

                    OutlinedTextField(
                        value = categoryIconEmoji,
                        onValueChange = { categoryIconEmoji = it },
                        label = { Text("Icon Emoji (e.g. 🛸, 🌍)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("dialog_emoji_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showAddCategoryDialog = false },
                            modifier = Modifier.weight(1f).testTag("dialog_cancel_btn")
                        ) {
                            Text("منسوخ کریں")
                        }

                        Button(
                            onClick = {
                                if (categoryUrduName.isNotBlank() && categoryEnglishName.isNotBlank()) {
                                    viewModel.addCustomCategory(
                                        categoryUrduName.trim(),
                                        categoryEnglishName.trim(),
                                        categoryIconEmoji.trim()
                                    )
                                    showAddCategoryDialog = false
                                }
                            },
                            modifier = Modifier.weight(1f).testTag("dialog_save_btn"),
                            enabled = categoryUrduName.isNotBlank() && categoryEnglishName.isNotBlank()
                        ) {
                            Text("محفوظ کریں")
                        }
                    }
                }
            }
        }
    }

    // Modal/Dialog 2: Post History Vault
    if (showPostHistoryDialog) {
        Dialog(onDismissRequest = { showPostHistoryDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.82f)
                    .testTag("history_dialog"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showPostHistoryDialog = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                        Text(
                            text = "تحریروں کا محفوظ خزانہ (Vault) 📚",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    if (postsHistory.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "ابھی تک کوئی تحریر محفوظ نہیں کی گئی ہے۔",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        androidx.compose.foundation.lazy.LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(postsHistory) { post ->
                                val dateStr = remember(post.timestamp) {
                                    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(post.timestamp))
                                }
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedHistoryPost = post }
                                        .testTag("history_post_item_${post.id}"),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = { viewModel.deletePostFromHistory(post) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(
                                                    text = post.title,
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    color = MaterialTheme.colorScheme.onSurface,
                                                    textAlign = TextAlign.End
                                                )
                                                Text(
                                                    text = "شعبہ: ${post.category} | $dateStr",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = post.content.take(130) + "...",
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 2,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            textAlign = TextAlign.End,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal/Dialog 3: History Post Detail Reader
    selectedHistoryPost?.let { post ->
        val dateStr = remember(post.timestamp) {
            SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(post.timestamp))
        }
        Dialog(onDismissRequest = { selectedHistoryPost = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .testTag("history_detail_dialog"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { selectedHistoryPost = null }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = post.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.End
                            )
                            Text(
                                text = "شعبہ: ${post.category} | $dateStr",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = post.content,
                            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 24.sp),
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.End
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // Low-profile English Image Generation Prompt Section
                    ImagePromptWidget(
                        imagePrompt = imagePrompt,
                        onCopyClick = { prompt ->
                            clipboardManager.setText(AnnotatedString(prompt))
                            Toast.makeText(context, "تصویر کا پرامپٹ کاپی ہو گیا ہے!", Toast.LENGTH_SHORT).show()
                        }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(post.content))
                                Toast.makeText(context, "پوسٹ کاپی ہو گئی ہے!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("📋 Copy Post")
                        }
                    }
                }
            }
        }
    }
}

// Inline replacement of binds to remove missing binds / unresolved reference errors
private fun Int.binddp() = this.dp

@Composable
fun ImagePromptWidget(
    imagePrompt: String?,
    onCopyClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Image Prompt",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    if (imagePrompt != null) {
                        Text(
                            text = imagePrompt,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Normal
                            ),
                            maxLines = 1,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                strokeWidth = 1.5.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "AI تصویر کا پرامپٹ تیار کیا جا رہا ہے...",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                if (imagePrompt != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = { onCopyClick(imagePrompt) },
                        contentPadding = PaddingValues(horizontal = 8.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("کاپی (Copy)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (!imagePrompt.isNullOrBlank()) {
            val pollinationUrl = remember(imagePrompt) {
                try {
                    val encoded = java.net.URLEncoder.encode(imagePrompt, "UTF-8")
                    "https://image.pollinations.ai/prompt/$encoded?width=600&height=600&nologo=true"
                } catch (e: Exception) {
                    ""
                }
            }
            if (pollinationUrl.isNotEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AsyncImage(
                            model = pollinationUrl,
                            contentDescription = "Live AI Preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.6f))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "✨ AI تصویر کا براہ راست منظر (Live Generated Image)",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}
