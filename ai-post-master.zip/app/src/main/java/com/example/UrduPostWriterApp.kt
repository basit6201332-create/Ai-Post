package com.example

import android.app.Application
import com.example.data.db.AppDatabase
import com.example.data.repository.PostRepository

class UrduPostWriterApp : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { PostRepository(database.appDao()) }

    override fun onCreate() {
        super.onCreate()
    }
}
