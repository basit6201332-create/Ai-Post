package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Multipart
import retrofit2.http.Part
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class FacebookError(
    @Json(name = "message") val message: String? = null,
    @Json(name = "type") val type: String? = null,
    @Json(name = "code") val code: Int? = null,
    @Json(name = "error_subcode") val errorSubcode: Int? = null,
    @Json(name = "fbtrace_id") val fbtraceId: String? = null
)

@JsonClass(generateAdapter = true)
data class FacebookPostResponse(
    @Json(name = "id") val id: String? = null,
    @Json(name = "error") val error: FacebookError? = null
)

interface FacebookApiService {
    @POST("{pageId}/feed")
    suspend fun postToPage(
        @Path("pageId") pageId: String,
        @Query("message") message: String,
        @Query("access_token") accessToken: String
    ): FacebookPostResponse

    @POST("{pageId}/photos")
    suspend fun postPhotoUrl(
        @Path("pageId") pageId: String,
        @Query("url") url: String,
        @Query("caption") caption: String,
        @Query("access_token") accessToken: String
    ): FacebookPostResponse

    @Multipart
    @POST("{pageId}/photos")
    suspend fun postPhotoFile(
        @Path("pageId") pageId: String,
        @Part file: MultipartBody.Part,
        @Part("caption") caption: RequestBody,
        @Part("access_token") accessToken: RequestBody
    ): FacebookPostResponse
}

object FacebookRetrofitClient {
    private const val BASE_URL = "https://graph.facebook.com/"

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: FacebookApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(FacebookApiService::class.java)
    }
}
