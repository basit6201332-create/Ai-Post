package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String, // E.g., unique identifier or slug
    val name: String, // Urdu Name
    val englishName: String, // English translation or identifier
    val icon: String, // Emoji representation
    val isCustom: Boolean, // True if added by user, false if pre-populated default
    val createdAt: Long = System.currentTimeMillis()
)
