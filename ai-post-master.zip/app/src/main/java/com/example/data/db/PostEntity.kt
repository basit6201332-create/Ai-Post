package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val content: String,
    val language: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isDraft: Boolean = false,
    val isPosted: Boolean = false,
    val imagePrompt: String? = null,
    val imageUrl: String? = null,
    val localImagePath: String? = null,
    val isScheduled: Boolean = false,
    val scheduledTime: Long = 0L,
    val allImages: String? = null
)
