package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.example.data.db.CategoryEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

object FirebaseManager {
    private const val TAG = "FirebaseManager"
    
    val isFirebaseInitialized: Boolean
        get() = try {
            FirebaseApp.getInstance()
            true
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not initialized: ${e.message}")
            false
        }

    val auth: FirebaseAuth?
        get() = if (isFirebaseInitialized) {
            try {
                FirebaseAuth.getInstance()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get FirebaseAuth instance: ${e.message}")
                null
            }
        } else {
            null
        }

    val currentUser: FirebaseUser?
        get() = auth?.currentUser

    private val firestore: FirebaseFirestore?
        get() = if (isFirebaseInitialized) {
            try {
                FirebaseFirestore.getInstance()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to get Firestore instance: ${e.message}")
                null
            }
        } else {
            null
        }

    /**
     * Saves a custom category to Firebase Firestore in real-time.
     */
    suspend fun saveCategoryToFirestore(category: CategoryEntity) {
        val db = firestore ?: return
        try {
            val data = hashMapOf(
                "id" to category.id,
                "name" to category.name,
                "englishName" to category.englishName,
                "icon" to category.icon,
                "isCustom" to category.isCustom,
                "createdAt" to category.createdAt
            )
            db.collection("custom_categories")
                .document(category.id)
                .set(data, SetOptions.merge())
                .await()
            Log.d(TAG, "Successfully synced category ${category.name} to Firestore.")
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing category to Firestore: ${e.message}", e)
        }
    }

    /**
     * Saves a custom category to Firebase Firestore under a user's collection.
     */
    suspend fun saveUserCategoryToFirestore(userId: String, category: CategoryEntity) {
        val db = firestore ?: return
        try {
            val data = hashMapOf(
                "id" to category.id,
                "name" to category.name,
                "englishName" to category.englishName,
                "icon" to category.icon,
                "isCustom" to category.isCustom,
                "createdAt" to category.createdAt
            )
            db.collection("users")
                .document(userId)
                .collection("custom_categories")
                .document(category.id)
                .set(data, SetOptions.merge())
                .await()
            Log.d(TAG, "Successfully synced custom category ${category.name} to Firestore for user $userId.")
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing user category to Firestore: ${e.message}", e)
        }
    }

    /**
     * Fetches all custom categories stored in Firebase Firestore to restore them on reload.
     */
    suspend fun fetchCustomCategoriesFromFirestore(): List<CategoryEntity> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshot = db.collection("custom_categories")
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getString("id") ?: return@mapNotNull null
                val name = doc.getString("name") ?: ""
                val englishName = doc.getString("englishName") ?: ""
                val icon = doc.getString("icon") ?: ""
                val isCustom = doc.getBoolean("isCustom") ?: true
                val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                
                CategoryEntity(
                    id = id,
                    name = name,
                    englishName = englishName,
                    icon = icon,
                    isCustom = isCustom,
                    createdAt = createdAt
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching from Firestore: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Fetches all user-specific custom categories stored in Firebase Firestore to restore them on reload/login.
     */
    suspend fun fetchUserCustomCategoriesFromFirestore(userId: String): List<CategoryEntity> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshot = db.collection("users")
                .document(userId)
                .collection("custom_categories")
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getString("id") ?: return@mapNotNull null
                val name = doc.getString("name") ?: ""
                val englishName = doc.getString("englishName") ?: ""
                val icon = doc.getString("icon") ?: ""
                val isCustom = doc.getBoolean("isCustom") ?: true
                val createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                
                CategoryEntity(
                    id = id,
                    name = name,
                    englishName = englishName,
                    icon = icon,
                    isCustom = isCustom,
                    createdAt = createdAt
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching user custom categories from Firestore: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Saves a used topic to Firebase Firestore under the current user's document
     */
    suspend fun saveUsedTopicToFirestore(userId: String, topic: String) {
        val db = firestore ?: return
        try {
            val sanitizedTopic = topic.trim()
            val topicHash = sanitizedTopic.hashCode().toString()
            val data = hashMapOf(
                "topic" to sanitizedTopic,
                "timestamp" to System.currentTimeMillis()
            )
            db.collection("users")
                .document(userId)
                .collection("used_topics")
                .document(topicHash)
                .set(data, SetOptions.merge())
                .await()
            Log.d(TAG, "Saved used topic '$sanitizedTopic' to Firestore for user: $userId")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving used topic to Firestore: ${e.message}", e)
        }
    }

    /**
     * Fetches the set of used topics for a given user from Firebase Firestore
     */
    suspend fun fetchUsedTopicsFromFirestore(userId: String): Set<String> {
        val db = firestore ?: return emptySet()
        return try {
            val snapshot = db.collection("users")
                .document(userId)
                .collection("used_topics")
                .get()
                .await()
            val topics = snapshot.documents.mapNotNull { doc ->
                doc.getString("topic")?.trim()
            }.toSet()
            Log.d(TAG, "Fetched ${topics.size} used topics from Firestore for user: $userId")
            topics
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching used topics from Firestore: ${e.message}", e)
            emptySet()
        }
    }

    /**
     * Saves a PostEntity (draft or scheduled post) to Firestore under the user's document
     */
    suspend fun savePostToFirestore(userId: String, post: com.example.data.db.PostEntity) {
        val db = firestore ?: return
        try {
            val data = hashMapOf(
                "id" to post.id,
                "title" to post.title,
                "category" to post.category,
                "content" to post.content,
                "language" to post.language,
                "timestamp" to post.timestamp,
                "isDraft" to post.isDraft,
                "isPosted" to post.isPosted,
                "imagePrompt" to post.imagePrompt,
                "imageUrl" to post.imageUrl,
                "localImagePath" to post.localImagePath,
                "isScheduled" to post.isScheduled,
                "scheduledTime" to post.scheduledTime,
                "allImages" to post.allImages
            )
            db.collection("users")
                .document(userId)
                .collection("posts")
                .document(post.id.toString())
                .set(data, SetOptions.merge())
                .await()
            Log.d(TAG, "Saved post ${post.id} to Firestore for user: $userId")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving post to Firestore: ${e.message}", e)
        }
    }

    /**
     * Deletes a PostEntity from Firestore under the user's document
     */
    suspend fun deletePostFromFirestore(userId: String, postId: Int) {
        val db = firestore ?: return
        try {
            db.collection("users")
                .document(userId)
                .collection("posts")
                .document(postId.toString())
                .delete()
                .await()
            Log.d(TAG, "Deleted post $postId from Firestore for user: $userId")
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting post from Firestore: ${e.message}", e)
        }
    }

    /**
     * Fetches all PostEntities for a given user from Firestore
     */
    suspend fun fetchPostsFromFirestore(userId: String): List<com.example.data.db.PostEntity> {
        val db = firestore ?: return emptyList()
        return try {
            val snapshot = db.collection("users")
                .document(userId)
                .collection("posts")
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                val id = doc.getLong("id")?.toInt() ?: return@mapNotNull null
                val title = doc.getString("title") ?: ""
                val category = doc.getString("category") ?: ""
                val content = doc.getString("content") ?: ""
                val language = doc.getString("language") ?: ""
                val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                val isDraft = doc.getBoolean("isDraft") ?: false
                val isPosted = doc.getBoolean("isPosted") ?: false
                val imagePrompt = doc.getString("imagePrompt")
                val imageUrl = doc.getString("imageUrl")
                val localImagePath = doc.getString("localImagePath")
                val isScheduled = doc.getBoolean("isScheduled") ?: false
                val scheduledTime = doc.getLong("scheduledTime") ?: 0L
                val allImages = doc.getString("allImages")

                com.example.data.db.PostEntity(
                    id = id,
                    title = title,
                    category = category,
                    content = content,
                    language = language,
                    timestamp = timestamp,
                    isDraft = isDraft,
                    isPosted = isPosted,
                    imagePrompt = imagePrompt,
                    imageUrl = imageUrl,
                    localImagePath = localImagePath,
                    isScheduled = isScheduled,
                    scheduledTime = scheduledTime,
                    allImages = allImages
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching posts from Firestore: ${e.message}", e)
            emptyList()
        }
    }

    /**
     * Saves Facebook credentials to Firebase Firestore under the current user's document
     */
    suspend fun saveUserCredentialsToFirestore(userId: String, pageId: String, accessToken: String) {
        val db = firestore ?: return
        try {
            val data = hashMapOf(
                "fbPageId" to pageId,
                "fbPageToken" to accessToken,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("users")
                .document(userId)
                .set(data, SetOptions.merge())
                .await()
            Log.d(TAG, "Saved fb credentials to Firestore for user: $userId")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving credentials to Firestore: ${e.message}", e)
        }
    }

    /**
     * Fetches Facebook credentials from Firestore for a given user
     */
    suspend fun fetchUserCredentialsFromFirestore(userId: String): Pair<String, String>? {
        val db = firestore ?: return null
        return try {
            val doc = db.collection("users")
                .document(userId)
                .get()
                .await()
            if (doc.exists()) {
                val pageId = doc.getString("fbPageId") ?: ""
                val accessToken = doc.getString("fbPageToken") ?: ""
                Pair(pageId, accessToken)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching credentials from Firestore: ${e.message}", e)
            null
        }
    }
}
