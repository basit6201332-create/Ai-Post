package com.example.data.repository

import android.util.Log
import com.example.data.db.AppDao
import com.example.data.db.CategoryEntity
import com.example.data.db.PostEntity
import com.example.data.firebase.FirebaseManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class PostRepository(private val appDao: AppDao) {
    private val TAG = "PostRepository"

    val allCategories: Flow<List<CategoryEntity>> = appDao.getAllCategories()
    val allPosts: Flow<List<PostEntity>> = appDao.getAllPosts()

    // Default Pre-populated categories
    val defaultCategories = listOf(
        CategoryEntity("space_astronomy", "خلا اور فلکیات", "Space & Astronomy", "🌌", false, 1L),
        CategoryEntity("history_archaeology", "تاریخ اور اثارِ قدیمہ", "History & Archaeology", "🏛️", false, 2L),
        CategoryEntity("medical_human_body", "میڈیکل اور انسانی جسم", "Medical & Human Body", "🧠", false, 3L),
        CategoryEntity("science_technology", "سائنس اور ٹیکنالوجی", "Science & Technology", "🔬", false, 4L)
    )

    /**
     * Pre-populates default categories and syncs custom ones from Firestore.
     */
    suspend fun initializeAndSync() {
        try {
            // 1. Insert pre-populated default categories into Room
            appDao.insertCategories(defaultCategories)
            
            // 2. Fetch custom categories from Firestore and save locally (legacy / global backup)
            if (FirebaseManager.isFirebaseInitialized) {
                val remoteCustomCategories = FirebaseManager.fetchCustomCategoriesFromFirestore()
                if (remoteCustomCategories.isNotEmpty()) {
                    Log.d(TAG, "Fetched ${remoteCustomCategories.size} custom categories from Firestore.")
                    remoteCustomCategories.forEach { category ->
                        appDao.insertCategory(category)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing repository: ${e.message}", e)
        }
    }

    /**
     * Fetches user-specific custom categories from Firestore and saves locally.
     */
    suspend fun syncUserCategories(userId: String) {
        try {
            if (FirebaseManager.isFirebaseInitialized) {
                val remoteUserCategories = FirebaseManager.fetchUserCustomCategoriesFromFirestore(userId)
                if (remoteUserCategories.isNotEmpty()) {
                    Log.d(TAG, "Fetched ${remoteUserCategories.size} user-specific custom categories from Firestore for user: $userId.")
                    remoteUserCategories.forEach { category ->
                        appDao.insertCategory(category)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing user-specific custom categories: ${e.message}", e)
        }
    }

    /**
     * Fetches user-specific posts (drafts, scheduled, history) from Firestore and saves locally.
     */
    suspend fun syncUserPosts(userId: String) {
        try {
            if (FirebaseManager.isFirebaseInitialized) {
                val remotePosts = FirebaseManager.fetchPostsFromFirestore(userId)
                if (remotePosts.isNotEmpty()) {
                    Log.d(TAG, "Fetched ${remotePosts.size} user-specific posts from Firestore for user: $userId.")
                    remotePosts.forEach { post ->
                        appDao.insertPost(post)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing user-specific posts: ${e.message}", e)
        }
    }

    /**
     * Adds a custom category locally and tries to sync to cloud.
     */
    suspend fun addCustomCategory(urduName: String, englishName: String, iconEmoji: String, userId: String? = null) {
        val slug = urduName.trim().lowercase().replace("\\s+".toRegex(), "_")
        val category = CategoryEntity(
            id = "custom_$slug",
            name = urduName,
            englishName = englishName,
            icon = iconEmoji,
            isCustom = true,
            createdAt = System.currentTimeMillis()
        )
        
        // Save locally first
        appDao.insertCategory(category)
        
        // Attempt cloud sync
        if (FirebaseManager.isFirebaseInitialized) {
            if (userId != null) {
                FirebaseManager.saveUserCategoryToFirestore(userId, category)
            } else {
                FirebaseManager.saveCategoryToFirestore(category)
            }
        }
    }

    /**
     * Inserts a written post to local history.
     */
    suspend fun savePost(title: String, categoryName: String, content: String, language: String) {
        val post = PostEntity(
            title = title,
            category = categoryName,
            content = content,
            language = language
        )
        appDao.insertPost(post)
    }

    suspend fun insertPost(post: PostEntity): Long {
        return appDao.insertPost(post)
    }

    suspend fun deletePost(post: PostEntity) {
        appDao.deletePost(post)
    }
}
