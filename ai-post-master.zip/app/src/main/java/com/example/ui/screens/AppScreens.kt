package com.example

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.ui.text.input.PasswordVisualTransformation
import coil.compose.AsyncImage
import com.example.data.db.CategoryEntity
import com.example.data.db.PostEntity
import com.example.data.firebase.FirebaseManager
import com.example.ui.viewmodel.PostViewModel

@Composable
fun HomeScreenView(
    viewModel: PostViewModel,
    onSignOut: () -> Unit,
    onNavigateToTab: (String) -> Unit
) {
    val context = LocalContext.current
    val categories by viewModel.categories.collectAsState()
    val draftPosts by viewModel.draftPosts.collectAsState()
    val publishedPosts by viewModel.publishedPosts.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var selectedHistoryPost by remember { mutableStateOf<PostEntity?>(null) }
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Welcome Header Banner with elegant artistic design
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (currentUser?.email?.take(1)?.uppercase() ?: "U"),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        Column {
                            // Calculate greeting based on current time
                            val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                            val greeting = when (hour) {
                                in 5..11 -> "صبح بخیر! 🌅"
                                in 12..16 -> "دوپہر بخیر! ☀️"
                                in 17..20 -> "شام بخیر! 🌆"
                                else -> "شب بخیر! 🌌"
                            }
                            Text(
                                text = greeting,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = currentUser?.email ?: "Urdu Post Writer Creator",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f), CircleShape)
                            .testTag("home_logout_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = "Sign Out",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // App Title & description with Stylish image
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "اردو ریسرچ اور تحریر انجن",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 0.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Urdu Post Research & Writing Engine",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                        modifier = Modifier.size(80.dp)
                    ) {
                        AsyncImage(
                            model = "https://image.pollinations.ai/prompt/Futuristic%20digital%20pen%20writing%20golden%20Urdu%20calligraphy%20on%20a%20sleek%20glowing%20tablet,%20cyberpunk%20technological%20background,%203d%20render?width=150&height=150&nologo=true",
                            contentDescription = "App Logo Banner",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Cloud Status Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (FirebaseManager.isFirebaseInitialized) 
                        Color(0xFFE8F5E9).copy(alpha = 0.8f) 
                    else 
                        Color(0xFFFFF3E0).copy(alpha = 0.8f)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (FirebaseManager.isFirebaseInitialized) Color(0xFFC8E6C9) else Color(0xFFFFE0B2)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                if (FirebaseManager.isFirebaseInitialized) Color(0xFF2E7D32) else Color(0xFFE65100),
                                CircleShape
                            )
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (FirebaseManager.isFirebaseInitialized) "☁️ Firebase Cloud Sync Active" else "💾 Local Offline Database Active",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = if (FirebaseManager.isFirebaseInitialized) Color(0xFF2E7D32) else Color(0xFFE65100)
                    )
                }
            }

            // Quick Stats Row
            Text(
                text = "کارکردگی اور اعداد و شمار (Statistics)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "ڈرافٹس (Drafts)",
                    count = draftPosts.size.toString(),
                    icon = Icons.Default.Info,
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "شائع شدہ (Posted)",
                    count = publishedPosts.size.toString(),
                    icon = Icons.Default.CheckCircle,
                    containerColor = Color(0xFFE8F5E9).copy(alpha = 0.8f),
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "زمرہ جات (Domains)",
                    count = categories.size.toString(),
                    icon = Icons.Default.List,
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.weight(1f)
                )
            }

            // Quick Actions Options
            Text(
                text = "فوری انتخابات (Quick Navigation)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionRow(
                    title = "نیا موضوع اور ڈرافٹ تلاش کریں",
                    subtitle = "Brainstorm & Compile Drafts",
                    icon = Icons.Default.Edit,
                    onClick = { onNavigateToTab("Brainstorm") }
                )
                QuickActionRow(
                    title = "محفوظ شدہ ڈرافٹس کھولیں",
                    subtitle = "Manage & Post Saved Drafts",
                    icon = Icons.Default.Info,
                    onClick = { onNavigateToTab("Drafts") }
                )
                QuickActionRow(
                    title = "سوشل میڈیا اور ایپ سیٹنگز",
                    subtitle = "Credentials setup & account configurations",
                    icon = Icons.Default.Settings,
                    onClick = { onNavigateToTab("Settings") }
                )
            }

            // Full Published History list embedded inside Home Page!
            Text(
                text = "شائع شدہ تحریروں کا ریکارڈ (Published History)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (publishedPosts.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "ابھی تک کوئی تاریخ ریکارڈ نہیں کی گئی۔",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        publishedPosts.forEach { post ->
                            val sdf = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
                            val formattedTime = sdf.format(java.util.Date(post.timestamp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedHistoryPost = post }
                                    .background(
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                IconButton(
                                    onClick = {
                                        viewModel.deletePost(post)
                                        Toast.makeText(context, "ہسٹری حذف کر دی گئی!", Toast.LENGTH_SHORT).show()
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Column(
                                    horizontalAlignment = Alignment.End,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = post.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        textAlign = TextAlign.End,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "زمرہ: ${post.category}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "•",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = formattedTime,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(Color(0xFFE8F5E9), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Inspiring quote card
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "ایک اچھی کہانی صرف کانوں کو ہی نہیں، روح کو بھی چھوتی ہے۔ ✨",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontStyle = FontStyle.Italic
                        ),
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "“A great story doesn't just touch the ears; it touches the soul.”",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            fontStyle = FontStyle.Italic
                        ),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Detail Dialog for selected history item
    selectedHistoryPost?.let { post ->
        val sdf = java.text.SimpleDateFormat("dd MMMM yyyy, hh:mm a", java.util.Locale.getDefault())
        val formattedTime = sdf.format(java.util.Date(post.timestamp))

        Dialog(onDismissRequest = { selectedHistoryPost = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { selectedHistoryPost = null }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                        Text(
                            text = "شائع شدہ تحریر کی تفصیلات",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    HorizontalDivider()

                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "عنوان: ${post.title}",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.End,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Text(
                            text = "زمرہ: ${post.category}",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.End
                        )

                        Text(
                            text = "شائع ہونے کا وقت: $formattedTime",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.End,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text(
                                text = "حیثیت: فیس بک پر کامیابی سے اپلوڈ ہو چکی ہے",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF2E7D32)
                            )
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .background(Color(0xFFE8F5E9), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { selectedHistoryPost = null },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("ٹھیک ہے (OK)")
                    }
                }
            }
        }
    }
}


@Composable
fun StatCard(
    title: String,
    count: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    containerColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = count, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = title, style = MaterialTheme.typography.labelSmall, maxLines = 1, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun QuickActionRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
                Column {
                    Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Go", tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun BrainstormScreenView(viewModel: PostViewModel) {
    val context = LocalContext.current
    val categories by viewModel.categories.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val suggestedSubCategories by viewModel.suggestedSubCategories.collectAsState()
    val selectedTopic by viewModel.selectedTopic.collectAsState()
    val isGeneratingTopics by viewModel.isGeneratingTopics.collectAsState()
    val isResearchingAndWriting by viewModel.isResearchingAndWriting.collectAsState()
    val generatedPost by viewModel.generatedPost.collectAsState()
    val imagePrompt by viewModel.imagePrompt.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val compilingDrafts by viewModel.compilingDrafts.collectAsState()
    val draftPosts by viewModel.draftPosts.collectAsState()
    val publishedPosts by viewModel.publishedPosts.collectAsState()
    val researchLogs by viewModel.researchLogs.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    var showAddCategoryDialog by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    val isCompilerActive = isResearchingAndWriting || generatedPost != null

    if (isCompilerActive) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header with Close/Reset Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.resetPostState() },
                    modifier = Modifier.testTag("compiler_close_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close Terminal", tint = MaterialTheme.colorScheme.onSurface)
                }
                
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "پوسٹ ریسرچ اور کمپائلیشن",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Research & Compilation Status",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            // Topic, Category & Subcategory Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        selectedCategory?.let { category ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(text = category.icon, fontSize = 16.sp)
                                Text(
                                    text = category.name,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                        
                        Text(
                            text = "موضوع اور زمرہ (Topic & Category)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    
                    Text(
                        text = selectedTopic,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            lineHeight = 24.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Running Animation (Show while compiling, or a subtle completed indicator if done)
            if (isResearchingAndWriting) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFF0F172A)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF334155))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        SpaceOrbitLoaderAnimation()
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color(0xFF00FFCC),
                            strokeWidth = 2.5.dp
                        )
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Text(
                            text = "ڈیپ ریسرچ اور تحریر جاری ہے...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00FFCC)
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ریسرچ اور تحریر مکمل ہو گئی ہے!",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }
            }

            // High-Tech Terminal Logs Container (Show researchLogs)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Color(0xFF1E293B))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFFEF4444), CircleShape))
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFFF59E0B), CircleShape))
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFF10B981), CircleShape))
                        }
                        Text(
                            text = "RESEARCH TERMINAL LOGS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF64748B),
                                letterSpacing = 1.sp
                            )
                        )
                    }
                    
                    HorizontalDivider(color = Color(0xFF1E293B))

                    val logsToShow = researchLogs
                    if (logsToShow.isEmpty()) {
                        Text(
                            text = "> Initializing compilation core...",
                            color = Color(0xFF00FFCC).copy(alpha = 0.8f),
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                        )
                    } else {
                        logsToShow.forEach { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Done",
                                    tint = Color(0xFF00FFCC),
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = log,
                                    color = Color(0xFFF1F5F9),
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // If we have a completed generated post, show it on the exact same page!
            generatedPost?.let { post ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generated_post_card_brainstorm"),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "تحریر کا نتیجہ (Result)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.align(Alignment.End)
                        )

                        HorizontalDivider()

                        SelectionContainer {
                            Text(
                                text = post,
                                style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 24.sp),
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        HorizontalDivider()

                        ImagePromptWidget(
                            imagePrompt = imagePrompt,
                            onCopyClick = { prompt ->
                                clipboardManager.setText(AnnotatedString(prompt))
                                Toast.makeText(context, "تصویر کا پرامپٹ کاپی ہو گیا ہے!", Toast.LENGTH_SHORT).show()
                            }
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(post))
                                    Toast.makeText(context, "کامیابی سے کاپی ہو گئی!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("کاپی (Copy)")
                            }
                            OutlinedButton(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, post)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "تحریر شیئر کریں"))
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("شیئر کریں")
                            }
                        }

                        HorizontalDivider()

                        FacebookPagePublisherCard(
                            viewModel = viewModel,
                            post = post,
                            selectedTopic = selectedTopic,
                            selectedCategoryName = selectedCategory?.name ?: ""
                        )
                    }
                }

                // Beautiful, fully integrated unified Facebook Preview, Multi-Image selector, Custom image adder, Draft, and Schedule Action Panel!
                EnhancedPostPreviewAndActions(
                    viewModel = viewModel,
                    postText = post,
                    title = selectedTopic,
                    category = selectedCategory?.name ?: "",
                    imagePrompt = imagePrompt ?: ""
                )
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Categories Header Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "اہم زمرہ جات (Categories)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )

                Button(
                    onClick = { showAddCategoryDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    modifier = Modifier
                        .height(36.dp)
                        .testTag("add_custom_category_btn_brainstorm")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("نیا کیٹیگری", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // FlowRow Grid of categories
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory?.id == category.id
                    Card(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .widthIn(min = 100.dp)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectCategory(category) }
                            .testTag("category_card_${category.id}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = category.icon, fontSize = 18.sp)
                            Column {
                                Text(
                                    text = category.name,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = category.englishName,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Suggested subcategories
            selectedCategory?.let { category ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🧠 ${category.name} سے متعلق منتخب موضوعات:",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (isGeneratingTopics) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.primary,
                                    strokeWidth = 2.dp
                                )
                            }
                        }
                        Text(
                            text = "Suggested post ideas. Click the checkbox to automatically compile and save as a draft, or tap the card to write immediately.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (isGeneratingTopics && suggestedSubCategories.isEmpty()) {
                            Text(
                                text = "تحقیق اور بہترین موضوعات کی تلاش جاری ہے...",
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                suggestedSubCategories.forEach { topic ->
                                    val isTopicSelected = selectedTopic == topic
                                    val isCompiling = compilingDrafts[topic] == true
                                    val isDrafted = draftPosts.any { it.title == topic }
                                    val isPublished = publishedPosts.any { it.title == topic }

                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.selectTopic(topic) },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isTopicSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                        ),
                                        shape = RoundedCornerShape(10.dp),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            // Left side check status
                                            Box(
                                                modifier = Modifier.size(36.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (isCompiling) {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(20.dp),
                                                        strokeWidth = 2.dp,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                } else if (isDrafted || isPublished) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = "Drafted",
                                                        tint = Color(0xFF2E7D32),
                                                        modifier = Modifier.size(24.dp)
                                                    )
                                                } else {
                                                    Checkbox(
                                                        checked = false,
                                                        onCheckedChange = { checked ->
                                                            if (checked) {
                                                                viewModel.compileTopicAsDraft(category.name, topic, context)
                                                                Toast.makeText(context, "ڈرافٹ بنانے کا کام بیک گراؤنڈ میں شروع ہو گیا ہے!", Toast.LENGTH_SHORT).show()
                                                            }
                                                        },
                                                        modifier = Modifier.testTag("draft_checkbox_$topic")
                                                    )
                                                }
                                            }

                                            // Right side topic text
                                            Text(
                                                text = topic,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = if (isTopicSelected) FontWeight.Bold else FontWeight.Medium
                                                ),
                                                color = if (isTopicSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
                                                modifier = Modifier.weight(1f),
                                                textAlign = TextAlign.End
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Research button
            if (selectedTopic.isNotEmpty()) {
                Button(
                    onClick = { viewModel.startResearchAndWriting() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("start_writing_button_brainstorm"),
                    shape = RoundedCornerShape(12.dp),
                    enabled = !isResearchingAndWriting
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Start research", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("موضوع پر ریسرچ اور تحریر شروع کریں ✨", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Error message
            errorMessage?.let { err ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(text = "⚠️ ریسرچ خرابی (Error)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = err, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }

        // Custom Category Dialog within Brainstorm
        if (showAddCategoryDialog) {
            var categoryUrduName by remember { mutableStateOf("") }
            var categoryEnglishName by remember { mutableStateOf("") }
            var categoryIconEmoji by remember { mutableStateOf("⭐") }

            Dialog(onDismissRequest = { showAddCategoryDialog = false }) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "جدید حسب منشا کیٹیگری شامل کریں",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.End
                        )
                        Text(
                            text = "Add a custom domain. It will automatically sync to your cloud backup so you never lose your workspace.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = categoryUrduName,
                            onValueChange = { categoryUrduName = it },
                            label = { Text("کیٹیگری کا اردو نام") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = categoryEnglishName,
                            onValueChange = { categoryEnglishName = it },
                            label = { Text("Category English Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = categoryIconEmoji,
                            onValueChange = { categoryIconEmoji = it },
                            label = { Text("Icon Emoji (e.g. 🛸, 🌍)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showAddCategoryDialog = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("منسوخ کریں")
                            }
                            Button(
                                onClick = {
                                    if (categoryUrduName.isNotBlank() && categoryEnglishName.isNotBlank()) {
                                        viewModel.addCustomCategory(categoryUrduName, categoryEnglishName, categoryIconEmoji)
                                        showAddCategoryDialog = false
                                        Toast.makeText(context, "نئی کیٹیگری کامیابی کے ساتھ شامل کر دی گئی ہے!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "تمام فیلڈز پُر کریں!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("شامل کریں")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DraftsScreenView(viewModel: PostViewModel) {
    val context = LocalContext.current
    val draftPosts by viewModel.draftPosts.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    var selectedDraftPost by remember { mutableStateOf<PostEntity?>(null) }

    if (draftPosts.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "No Drafts",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(54.dp)
                    )
                    Text(
                        text = "کوئی ڈرافٹ دستیاب نہیں ہے!",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Brainstorm and check any topic box to compile it into a local draft post in the background.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "محفوظ شدہ ڈرافٹس (Compiled Drafts)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(draftPosts) { draft ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedDraftPost = draft },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Show generated image thumbnail on the left
                            val imgSource = draft.localImagePath ?: draft.imageUrl
                            if (imgSource != null) {
                                AsyncImage(
                                    model = imgSource,
                                    contentDescription = "Draft Image",
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }

                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = draft.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        textAlign = TextAlign.End
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "زمرہ: ${draft.category}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Detail dialog
    selectedDraftPost?.let { post ->
        Dialog(onDismissRequest = { selectedDraftPost = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ڈرافٹ فائل (Draft File)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row {
                            IconButton(onClick = {
                                viewModel.deletePost(post)
                                selectedDraftPost = null
                                Toast.makeText(context, "ڈرافٹ حذف کر دیا گیا ہے!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                            IconButton(onClick = { selectedDraftPost = null }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                            }
                        }
                    }

                    HorizontalDivider()

                    // Beautiful fully integrated Actions and Preview widget for consistent Draft actions
                    EnhancedPostPreviewAndActions(
                        viewModel = viewModel,
                        postText = post.content,
                        title = post.title,
                        category = post.category,
                        imagePrompt = post.imagePrompt ?: "",
                        existingPostEntity = post,
                        onNavigateBack = { selectedDraftPost = null }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreenView(viewModel: PostViewModel) {
    val context = LocalContext.current
    val publishedPosts by viewModel.publishedPosts.collectAsState()
    val clipboardManager = LocalClipboardManager.current

    var selectedHistoryPost by remember { mutableStateOf<PostEntity?>(null) }

    if (publishedPosts.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.List,
                        contentDescription = "No Published",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(54.dp)
                    )
                    Text(
                        text = "ابھی تک کوئی تحریر شائع نہیں ہوئی!",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "When you post/publish compiled drafts, their titles are synced to your cloud account and their content is stored here safely.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "شائع شدہ تحریریں (Published Posts)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(publishedPosts) { post ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedHistoryPost = post },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            IconButton(
                                onClick = {
                                    viewModel.deletePostFromHistory(post)
                                    Toast.makeText(context, "تحریر حذف کر دی گئی!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }

                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = post.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        textAlign = TextAlign.End
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "زمرہ: ${post.category}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFE8F5E9), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color(0xFF2E7D32))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Detail dialog
    selectedHistoryPost?.let { post ->
        Dialog(onDismissRequest = { selectedHistoryPost = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "شائع شدہ تحریر (Published Post)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(onClick = { selectedHistoryPost = null }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    HorizontalDivider()

                    Text(
                        text = "موضوع: ${post.title}",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Show full generated image in history detail preview
                    val dialogImage = post.localImagePath ?: post.imageUrl
                    if (dialogImage != null) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                        ) {
                            Box(modifier = Modifier.fillMaxSize()) {
                                AsyncImage(
                                    model = dialogImage,
                                    contentDescription = "Generated Post Image",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .padding(8.dp)
                                        .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (post.localImagePath != null) "Imagen 4.0" else "Pollinations AI",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    SelectionContainer {
                        Text(
                            text = post.content,
                            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 24.sp),
                            textAlign = TextAlign.End,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    HorizontalDivider()

                    ImagePromptWidget(
                        imagePrompt = post.imagePrompt,
                        onCopyClick = { prompt ->
                            clipboardManager.setText(AnnotatedString(prompt))
                            Toast.makeText(context, "تصویر کا پرامپٹ کاپی ہو گیا ہے!", Toast.LENGTH_SHORT).show()
                        }
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(post.content))
                                Toast.makeText(context, "کامیابی سے کاپی ہو گئی!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("کاپی (Copy)")
                        }
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, post.content)
                                }
                                context.startActivity(Intent.createChooser(intent, "تحریر شیئر کریں"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("شیئر کریں")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreenView(viewModel: PostViewModel) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val currentUser by viewModel.currentUser.collectAsState()

    var pageId by remember { mutableStateOf("") }
    var accessToken by remember { mutableStateOf("") }
    var saveCredentials by remember { mutableStateOf(true) }

    val userId = currentUser?.uid ?: ""

    // Read stored credentials on load or user change
    LaunchedEffect(userId) {
        if (userId.isNotEmpty()) {
            val prefs = context.getSharedPreferences("fb_prefs", android.content.Context.MODE_PRIVATE)
            pageId = prefs.getString("page_id_$userId", "") ?: ""
            accessToken = prefs.getString("access_token_$userId", "") ?: ""
            saveCredentials = prefs.getBoolean("saved_$userId", true)
        } else {
            pageId = ""
            accessToken = ""
            saveCredentials = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upper Title Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ایپ ترتیبات (Settings & Configuration)",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings Icon",
                tint = MaterialTheme.colorScheme.primary
            )
        }

        HorizontalDivider()

        // Configuration and User Profile View
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // User Profile Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "صارف کا پروفائل (User Profile Info)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(54.dp)
                                .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (currentUser?.email?.take(1)?.uppercase() ?: "U"),
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Column {
                            Text(
                                text = currentUser?.email ?: "Urdu Writer Creator",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "جی میل / فائر بیس اکاؤنٹ",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // User ID display with Copy button
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "صارف آئی ڈی (User ID):",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = currentUser?.uid ?: "NOT_LOGGED_IN",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    currentUser?.uid?.let { uid ->
                                        clipboardManager.setText(AnnotatedString(uid))
                                        Toast.makeText(context, "صارف آئی ڈی کاپی ہو گئی ہے!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Copy UID",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            // Facebook Credentials Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "فیس بک پیج کنفیگریشن (Facebook Page Setup)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "Set your Facebook Page Credentials here. Once saved, they will automatically sync to let you research, write, and auto-publish content with one single click.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = pageId,
                        onValueChange = { pageId = it },
                        label = { Text("فیس بک پیج آئی ڈی (Facebook Page ID)") },
                        placeholder = { Text("Enter Page ID (numeric)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = accessToken,
                        onValueChange = { accessToken = it },
                        label = { Text("پیج ایکسس ٹوکن (Page Access Token)") },
                        placeholder = { Text("EAA...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ترتیبات محفوظ رکھیں (Keep Credentials)?",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Switch(
                            checked = saveCredentials,
                            onCheckedChange = { saveCredentials = it }
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.saveFacebookCredentials(context, pageId, accessToken, saveCredentials) { success ->
                                if (success) {
                                    if (saveCredentials) {
                                        Toast.makeText(context, "ترتیبات کامیابی کے ساتھ محفوظ اور کلاؤڈ پر سنک کر دی گئی ہیں!", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "ترتیبات کامیابی کے ساتھ حذف کر دی گئی ہیں!", Toast.LENGTH_SHORT).show()
                                        pageId = ""
                                        accessToken = ""
                                    }
                                } else {
                                    Toast.makeText(context, "ترتیبات محفوظ کرنے میں خرابی پیش آئی!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = "Save Settings")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ترتیبات محفوظ کریں (Save Settings)")
                    }
                }
            }
        }
    }
}

// ==========================================================
// SOCIAL MEDIA REAL-TIME PREVIEWS
// ==========================================================

@Composable
fun SocialMediaPreviewWidget(post: String, imagePrompt: String) {
    var selectedPlatform by remember { mutableStateOf("Facebook") }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("social_media_preview_container"),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سوشل میڈیا پریویو (Platform Previews)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            Text(
                text = "یہ تحریر سوشل میڈیا پلیٹ فارمز پر کیسی نظر آئے گی، اس کا حقیقی نمونہ نیچے دیکھیں:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.End,
                modifier = Modifier.fillMaxWidth()
            )
            
            // Small Tabs/Icons for Facebook, WhatsApp, Twitter (X), YouTube
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val platforms = listOf(
                    PlatformItem("Facebook", "👤", Color(0xFF1877F2), "فیس بک"),
                    PlatformItem("WhatsApp", "💬", Color(0xFF25D366), "واٹس ایپ"),
                    PlatformItem("Twitter", "🐦", Color(0xFF111111), "ٹویٹر (X)"),
                    PlatformItem("YouTube", "🎥", Color(0xFFFF0000), "یوٹیوب")
                )
                
                platforms.forEach { platform ->
                    val isSelected = selectedPlatform == platform.id
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 4.dp)
                            .clickable { selectedPlatform = platform.id }
                            .testTag("preview_tab_${platform.id.lowercase()}"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) platform.brandColor else MaterialTheme.colorScheme.outlineVariant
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) platform.brandColor.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = platform.emoji,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                            Text(
                                text = platform.urduLabel,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSelected) platform.brandColor else MaterialTheme.colorScheme.onSurface,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
            
            // Preview Render Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    .background(
                        if (selectedPlatform == "Twitter") {
                            Color(0xFF000000)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
                        }
                    )
                    .padding(12.dp)
            ) {
                when (selectedPlatform) {
                    "Facebook" -> FacebookPreview(post = post, imagePrompt = imagePrompt)
                    "WhatsApp" -> WhatsAppPreview(post = post)
                    "Twitter" -> TwitterPreview(post = post, imagePrompt = imagePrompt)
                    "YouTube" -> YouTubePreview(post = post, imagePrompt = imagePrompt)
                }
            }
        }
    }
}

data class PlatformItem(
    val id: String,
    val emoji: String,
    val brandColor: Color,
    val urduLabel: String
)

@Composable
fun FacebookPreview(post: String, imagePrompt: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Facebook Top Profile Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Options icon
            Text(text = "•••", color = Color.Gray, fontSize = 14.sp)
            
            // Profile info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "اردو پوسٹ رائٹر AI",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF1877F2)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(text = "🌐", fontSize = 10.sp)
                        Text(text = "Just now · ", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF1877F2).copy(alpha = 0.1f), CircleShape)
                        .border(1.5.dp, Color(0xFF1877F2), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🤖", fontSize = 20.sp)
                }
            }
        }
        
        // Post text RTL
        Text(
            text = post,
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
            textAlign = TextAlign.End,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.onSurface
        )
        
        // Image prompt preview if it exists
        if (imagePrompt.isNotEmpty()) {
            val pollinationUrl = remember(imagePrompt) {
                try {
                    val encoded = java.net.URLEncoder.encode(imagePrompt, "UTF-8")
                    "https://image.pollinations.ai/prompt/$encoded?width=600&height=600&nologo=true"
                } catch (e: Exception) {
                    ""
                }
            }
            if (pollinationUrl.isNotEmpty()) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .border(1.dp, Color(0xFF1877F2).copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AsyncImage(
                            model = pollinationUrl,
                            contentDescription = "AI Generated Visual",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.65f))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "تصویر کا تجویز کردہ ڈیزائن (Live AI Preview)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF1877F2)
                                )
                                Text(
                                    text = imagePrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
        
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        
        // Facebook bottom bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "Share", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "Comment", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Icon(imageVector = Icons.Default.Check, contentDescription = "Comment", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "Like", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1877F2), fontWeight = FontWeight.Bold)
                Icon(imageVector = Icons.Default.ThumbUp, contentDescription = "Like", tint = Color(0xFF1877F2), modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun WhatsAppPreview(post: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFE5DDD5))
            .border(1.dp, Color(0xFFB0BEC5), RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF075E54))
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = Color.White, modifier = Modifier.size(18.dp))
                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Status", tint = Color.White, modifier = Modifier.size(18.dp))
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "اردو رائٹر AI", color = Color.White, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Text(text = "online", color = Color(0xFF25D366), style = MaterialTheme.typography.labelSmall)
                }
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(Color.White.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "💬", fontSize = 16.sp)
                }
            }
        }
        
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Card(
                modifier = Modifier.widthIn(max = 280.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE2F9C3)
                ),
                shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp, bottomEnd = 8.dp),
                border = BorderStroke(0.5.dp, Color(0xFFC5E1A5))
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = post,
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
                        textAlign = TextAlign.End,
                        color = Color(0xFF1E293B),
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "12:00 PM", fontSize = 10.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "✓✓", fontSize = 12.sp, color = Color(0xFF34B7F1), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun TwitterPreview(post: String, imagePrompt: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "X", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(text = "✓", color = Color(0xFF1DA1F2), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(text = "UrduWriterAI", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    }
                    Text(text = "@UrduWriterAI · 1s", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🐦", fontSize = 18.sp)
                }
            }
        }
        
        Text(
            text = post,
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
            textAlign = TextAlign.End,
            modifier = Modifier.fillMaxWidth(),
            color = Color.White
        )
        
        if (imagePrompt.isNotEmpty()) {
            val pollinationUrl = remember(imagePrompt) {
                try {
                    val encoded = java.net.URLEncoder.encode(imagePrompt, "UTF-8")
                    "https://image.pollinations.ai/prompt/$encoded?width=600&height=600&nologo=true"
                } catch (e: Exception) {
                    ""
                }
            }
            if (pollinationUrl.isNotEmpty()) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .border(1.dp, Color(0xFF38444D), RoundedCornerShape(12.dp))
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AsyncImage(
                            model = pollinationUrl,
                            contentDescription = "AI Generated Visual",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "AI Visual Preview",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF1DA1F2)
                                )
                                Text(
                                    text = imagePrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
        
        HorizontalDivider(color = Color(0xFF38444D))
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "5", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Icon(imageVector = Icons.Default.Favorite, contentDescription = "Like", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(text = "1", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Retweet", tint = Color.Gray, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun YouTubePreview(post: String, imagePrompt: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "⋮", color = Color.Gray, fontSize = 18.sp)
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "✓", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = "اردو رائٹر AI",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(text = "Just now", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFFFF0000).copy(alpha = 0.1f), CircleShape)
                        .border(1.dp, Color(0xFFFF0000), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🎥", fontSize = 16.sp)
                }
            }
        }
        
        Text(
            text = post,
            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
            textAlign = TextAlign.End,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.onSurface
        )
        
        if (imagePrompt.isNotEmpty()) {
            val pollinationUrl = remember(imagePrompt) {
                try {
                    val encoded = java.net.URLEncoder.encode(imagePrompt, "UTF-8")
                    "https://image.pollinations.ai/prompt/$encoded?width=600&height=600&nologo=true"
                } catch (e: Exception) {
                    ""
                }
            }
            if (pollinationUrl.isNotEmpty()) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        AsyncImage(
                            model = pollinationUrl,
                            contentDescription = "AI Generated Visual",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(8.dp)
                        ) {
                            Column {
                                Text(
                                    text = "تجویز کردہ تصویری خاکہ (Visual Design Prompt)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFFFF0000)
                                )
                                Text(
                                    text = imagePrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
        
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = Color.Gray, modifier = Modifier.size(18.dp))
            
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "Comments", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = "Comments", tint = Color.Gray, modifier = Modifier.size(16.dp))
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(text = "12", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    Icon(imageVector = Icons.Default.ThumbUp, contentDescription = "Like", tint = Color.Gray, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun FacebookPagePublisherCard(
    viewModel: PostViewModel,
    post: String,
    selectedTopic: String,
    selectedCategoryName: String,
    postId: Int? = null
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val userId = currentUser?.uid ?: ""

    var pageId by remember { mutableStateOf("") }
    var accessToken by remember { mutableStateOf("") }

    // Read stored credentials on load or user change
    LaunchedEffect(userId) {
        if (userId.isNotEmpty()) {
            val prefs = context.getSharedPreferences("fb_prefs", android.content.Context.MODE_PRIVATE)
            pageId = prefs.getString("page_id_$userId", "") ?: ""
            accessToken = prefs.getString("access_token_$userId", "") ?: ""
        } else {
            pageId = ""
            accessToken = ""
        }
    }

    val isPostingToFacebook by viewModel.isPostingToFacebook.collectAsState()
    val facebookPostStatus by viewModel.facebookPostStatus.collectAsState()
    val facebookPostSuccess by viewModel.facebookPostSuccess.collectAsState()
    val facebookSuccessPosts by viewModel.facebookSuccessPosts.collectAsState()

    // Determine success based on either general status or specific post ID
    val isSuccess = facebookPostSuccess || (postId != null && facebookSuccessPosts.contains(postId))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("facebook_publisher_card"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "فیس بک پیج آٹو پبلشنگ (FB Auto-Publish)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(text = "👥", fontSize = 18.sp)
                }
            }

            if (pageId.isBlank() || accessToken.isBlank()) {
                // Warning / Helper Info Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "ترتیبات کنفیگر نہیں ہیں",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Right
                        )
                        Text(
                            text = "فیس بک آٹو پبلشنگ کی ترتیبات ابھی خالی ہیں۔ براہ کرم ایپ کی 'سیٹنگز' ٹیب میں جا کر اپنے فیس بک پیج کی آئی ڈی اور ایکسس ٹوکن کنفیگر کریں۔",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            } else {
                // Action / Status Area
                if (isSuccess) {
                    // Succesful published state! Display beautiful green badge
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("fb_published_success_badge"),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF2E7D32)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Success Checkmark",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "فیس بک پیج پر کامیابی سے پوسٹ ہو چکی ہے!",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }
                } else {
                    // Action Button
                    Button(
                        onClick = {
                            viewModel.publishToFacebook(
                                context = context,
                                pageId = pageId,
                                accessToken = accessToken,
                                postText = post,
                                postTitle = selectedTopic,
                                categoryName = selectedCategoryName,
                                saveCredentials = false, // Settings handles actual saving now!
                                postId = postId,
                                onComplete = { success ->
                                    if (success) {
                                        Toast.makeText(context, "فیس بک پر پوسٹ کامیابی سے اپلوڈ ہو گئی!", Toast.LENGTH_LONG).show()
                                    }
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("fb_post_now_button"),
                        enabled = !isPostingToFacebook && pageId.isNotBlank() && accessToken.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1877F2),
                            disabledContainerColor = Color(0xFF1877F2).copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (isPostingToFacebook) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "فیس بک پیج پر ابھی پوسٹ کریں",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }

                    // Line Animation and Status message when uploading/processing
                    if (isPostingToFacebook) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .testTag("fb_publish_progress_bar"),
                                color = Color(0xFF1877F2),
                                trackColor = Color(0xFF1877F2).copy(alpha = 0.2f)
                            )
                            Text(
                                text = facebookPostStatus,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = Color(0xFF1877F2),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================================
// UNIFIED POST PREVIEW & ACTIONS PANELS (M3 Urdu)
// ==========================================================

@Composable
fun EnhancedPostPreviewAndActions(
    viewModel: PostViewModel,
    postText: String,
    title: String,
    category: String,
    imagePrompt: String,
    existingPostEntity: PostEntity? = null,
    onNavigateBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val generatedImages by viewModel.generatedImages.collectAsState()
    val selectedImageIndex by viewModel.selectedImageIndex.collectAsState()
    
    // Extract images
    LaunchedEffect(postText, existingPostEntity) {
        if (existingPostEntity != null) {
            val imgs = existingPostEntity.allImages?.split(",")?.filter { it.isNotBlank() }
                ?: listOf(existingPostEntity.imageUrl).filterNotNull()
            val index = if (existingPostEntity.imageUrl != null) {
                val found = imgs.indexOf(existingPostEntity.imageUrl)
                if (found >= 0) found else 0
            } else 0
            viewModel.setGeneratedImages(imgs, index)
        }
    }

    val currentImage = generatedImages.getOrNull(selectedImageIndex) ?: ""

    var showAddImageDialog by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var customImageUrl by remember { mutableStateOf("") }
    
    // Scheduling states
    var scheduleHours by remember { mutableStateOf("12") }
    var scheduleMinutes by remember { mutableStateOf("00") }
    var scheduleAmPm by remember { mutableStateOf("PM") }
    var scheduleDaysAhead by remember { mutableStateOf("0") } // 0 = Today, 1 = Tomorrow, etc.

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // FACEBOOK PREVIEW LAYOUT (Urdu Styled)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header with App Profile
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "•••", color = Color.Gray, fontSize = 14.sp)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "اردو پوسٹ رائٹر AI",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF1877F2)
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(text = "🌐", fontSize = 10.sp)
                                Text(text = "Just now · ", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color(0xFF1877F2).copy(alpha = 0.1f), CircleShape)
                                .border(1.5.dp, Color(0xFF1877F2), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🤖", fontSize = 20.sp)
                        }
                    }
                }

                // Post Content Text (RTL)
                SelectionContainer {
                    Text(
                        text = postText,
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Main Image Display inside Preview
                if (currentImage.isNotEmpty()) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .border(1.dp, Color(0xFF1877F2).copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            AsyncImage(
                                model = currentImage,
                                contentDescription = "Post Image",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = imagePrompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White,
                                    maxLines = 2,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            // CAROUSEL IMAGE SELECTOR AND ADD IMAGE BUTTON
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left side: Add Image Button
                OutlinedButton(
                    onClick = { showAddImageDialog = true },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_custom_image_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تصویر شامل کریں", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                // Right side: Image numbers selector
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تصویر منتخب کریں:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    generatedImages.forEachIndexed { idx, _ ->
                        val isSel = selectedImageIndex == idx
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(
                                    if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    CircleShape
                                )
                                .border(1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable { viewModel.selectImageIndex(idx) }
                                .testTag("image_select_$idx"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = (idx + 1).toString(),
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            HorizontalDivider()

            // ACTION BUTTONS (Publish, Draft, Schedule)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Draft Button
                    Button(
                        onClick = {
                            viewModel.saveGeneratedAsDraft(
                                title = title,
                                category = category,
                                content = postText,
                                imagePrompt = imagePrompt,
                                images = generatedImages,
                                selectedIndex = selectedImageIndex
                            )
                            Toast.makeText(context, "ڈرافٹ کامیابی سے محفوظ کر لیا گیا ہے!", Toast.LENGTH_SHORT).show()
                            onNavigateBack?.invoke()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("action_save_draft_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("ڈرافٹ محفوظ کریں", fontWeight = FontWeight.Bold)
                    }

                    // Schedule Button
                    Button(
                        onClick = { showScheduleDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("action_schedule_post_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Text("شیڈیول کریں (Schedule)", fontWeight = FontWeight.Bold)
                    }
                }

                // Facebook Publisher Card Integration
                FacebookPagePublisherCard(
                    viewModel = viewModel,
                    post = postText,
                    selectedTopic = title,
                    selectedCategoryName = category,
                    postId = existingPostEntity?.id
                )
            }
        }
    }

    // ADD CUSTOM IMAGE DIALOG
    if (showAddImageDialog) {
        AlertDialog(
            onDismissRequest = { showAddImageDialog = false },
            title = {
                Text(
                    text = "اپنی تصویر شامل کریں (Add Custom Image)",
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "براہ کرم تصویر کا انٹرنیٹ لنک (URL) نیچے درج کریں:",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = customImageUrl,
                        onValueChange = { customImageUrl = it },
                        placeholder = { Text("https://example.com/image.jpg") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (customImageUrl.isNotBlank()) {
                            viewModel.addCustomImage(customImageUrl)
                            customImageUrl = ""
                            showAddImageDialog = false
                            Toast.makeText(context, "تصویر کامیابی سے شامل ہو گئی ہے!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("شامل کریں")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddImageDialog = false }) {
                    Text("کینسل")
                }
            }
        )
    }

    // SCHEDULE DIALOG
    if (showScheduleDialog) {
        AlertDialog(
            onDismissRequest = { showScheduleDialog = false },
            title = {
                Text(
                    text = "پوسٹ شیڈیول کریں (Schedule Post)",
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth(),
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "براہ کرم تاریخ اور وقت منتخب کریں جب آپ اس پوسٹ کو فیس بک پر خودکار طور پر شائع کرنا چاہتے ہیں:",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Days selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("0" to "آج", "1" to "کل", "2" to "پرسوں").forEach { (valStr, label) ->
                                val isSel = scheduleDaysAhead == valStr
                                FilterChip(
                                    selected = isSel,
                                    onClick = { scheduleDaysAhead = valStr },
                                    label = { Text(label) }
                                )
                            }
                        }
                        Text("دن منتخب کریں:", style = MaterialTheme.typography.labelSmall)
                    }

                    // Time fields
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // AM / PM
                        Row(modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("AM", "PM").forEach { ampm ->
                                val isSel = scheduleAmPm == ampm
                                FilterChip(
                                    selected = isSel,
                                    onClick = { scheduleAmPm = ampm },
                                    label = { Text(ampm) }
                                )
                            }
                        }
                        
                        // Minute
                        OutlinedTextField(
                            value = scheduleMinutes,
                            onValueChange = { scheduleMinutes = it.take(2) },
                            placeholder = { Text("00") },
                            singleLine = true,
                            modifier = Modifier.width(60.dp),
                            label = { Text("منٹ") }
                        )

                        Text(":")

                        // Hour
                        OutlinedTextField(
                            value = scheduleHours,
                            onValueChange = { scheduleHours = it.take(2) },
                            placeholder = { Text("12") },
                            singleLine = true,
                            modifier = Modifier.width(60.dp),
                            label = { Text("گھنٹہ") }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val hours = scheduleHours.toIntOrNull() ?: 12
                        val minutes = scheduleMinutes.toIntOrNull() ?: 0
                        val daysAhead = scheduleDaysAhead.toIntOrNull() ?: 0
                        
                        // Calculate timestamp
                        val calendar = java.util.Calendar.getInstance()
                        calendar.add(java.util.Calendar.DAY_OF_YEAR, daysAhead)
                        
                        var finalHour = hours
                        if (scheduleAmPm == "PM" && hours < 12) finalHour += 12
                        if (scheduleAmPm == "AM" && hours == 12) finalHour = 0
                        
                        calendar.set(java.util.Calendar.HOUR_OF_DAY, finalHour)
                        calendar.set(java.util.Calendar.MINUTE, minutes)
                        calendar.set(java.util.Calendar.SECOND, 0)
                        
                        val scheduledTime = calendar.timeInMillis
                        
                        val postToSchedule = existingPostEntity ?: PostEntity(
                            title = title,
                            category = category,
                            content = postText,
                            language = "Urdu",
                            isDraft = false,
                            isPosted = false,
                            imagePrompt = imagePrompt,
                            imageUrl = currentImage,
                            allImages = generatedImages.joinToString(",")
                        )
                        
                        viewModel.schedulePost(postToSchedule, scheduledTime)
                        showScheduleDialog = false
                        Toast.makeText(context, "پوسٹ کامیابی کے ساتھ شیڈیول ہو گئی ہے!", Toast.LENGTH_LONG).show()
                        onNavigateBack?.invoke()
                    }
                ) {
                    Text("شیڈیول کریں")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScheduleDialog = false }) {
                    Text("کینسل")
                }
            }
        )
    }
}

@Composable
fun ScheduledScreenView(viewModel: PostViewModel) {
    val context = LocalContext.current
    val scheduledPosts by viewModel.scheduledPosts.collectAsState()
    var selectedScheduledPost by remember { mutableStateOf<PostEntity?>(null) }

    if (scheduledPosts.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "No Scheduled Posts",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                        modifier = Modifier.size(54.dp)
                    )
                    Text(
                        text = "کوئی شیڈیول پوسٹ نہیں ہے!",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Drafts or generated posts can be scheduled to auto-publish on Facebook at any selected future time.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "شیڈیول کی گئی پوسٹس (Scheduled Posts)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(scheduledPosts) { post ->
                    val sdf = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
                    val formattedTime = sdf.format(java.util.Date(post.scheduledTime))

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedScheduledPost = post },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val imgSource = post.imageUrl
                            if (!imgSource.isNullOrBlank()) {
                                AsyncImage(
                                    model = imgSource,
                                    contentDescription = "Scheduled Post Image",
                                    modifier = Modifier
                                        .size(50.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                            }

                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = post.title,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        textAlign = TextAlign.End
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "وقت: $formattedTime",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    selectedScheduledPost?.let { post ->
        Dialog(onDismissRequest = { selectedScheduledPost = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "شیڈیول فائل (Scheduled)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row {
                            IconButton(onClick = {
                                viewModel.deletePost(post)
                                selectedScheduledPost = null
                                Toast.makeText(context, "پوسٹ حذف کر دی گئی ہے!", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                            }
                            IconButton(onClick = { selectedScheduledPost = null }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                            }
                        }
                    }

                    HorizontalDivider()

                    val sdf = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
                    val formattedTime = sdf.format(java.util.Date(post.scheduledTime))

                    Text(
                        text = "یہ پوسٹ خودکار طور پر اس وقت شائع ہو گی:\n$formattedTime",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    HorizontalDivider()

                    EnhancedPostPreviewAndActions(
                        viewModel = viewModel,
                        postText = post.content,
                        title = post.title,
                        category = post.category,
                        imagePrompt = post.imagePrompt ?: "",
                        existingPostEntity = post,
                        onNavigateBack = { selectedScheduledPost = null }
                    )
                }
            }
        }
    }
}
