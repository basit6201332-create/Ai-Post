package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.api.Content
import com.example.data.api.GenerateContentRequest
import com.example.data.api.GenerateContentResponse
import com.example.data.api.GenerateImagesRequest
import com.example.data.api.Part
import com.example.data.api.RetrofitClient
import com.example.data.api.FacebookRetrofitClient
import com.example.data.db.CategoryEntity
import com.example.data.db.PostEntity
import com.example.data.repository.PostRepository
import com.example.data.firebase.FirebaseManager
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.net.URLEncoder

class PostViewModel(private val repository: PostRepository) : ViewModel() {

    // Categories and Posts fetched from Repository
    val categories: StateFlow<List<CategoryEntity>> = repository.allCategories
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val postsHistory: StateFlow<List<PostEntity>> = repository.allPosts
        .map { list -> list.filter { it.isPosted || (!it.isDraft && !it.isPosted && !it.isScheduled) } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val draftPosts: StateFlow<List<PostEntity>> = repository.allPosts
        .map { list -> list.filter { it.isDraft && !it.isPosted && !it.isScheduled } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val scheduledPosts: StateFlow<List<PostEntity>> = repository.allPosts
        .map { list -> list.filter { it.isScheduled && !it.isPosted } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val publishedPosts: StateFlow<List<PostEntity>> = repository.allPosts
        .map { list -> list.filter { it.isPosted } }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Authentication States
    private val _currentUser = MutableStateFlow<FirebaseUser?>(FirebaseManager.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // Current Selection States
    private val _selectedCategory = MutableStateFlow<CategoryEntity?>(null)
    val selectedCategory: StateFlow<CategoryEntity?> = _selectedCategory.asStateFlow()

    private val _suggestedSubCategories = MutableStateFlow<List<String>>(emptyList())
    val suggestedSubCategories: StateFlow<List<String>> = _suggestedSubCategories.asStateFlow()

    private val _selectedTopic = MutableStateFlow("")
    val selectedTopic: StateFlow<String> = _selectedTopic.asStateFlow()

    private val _generatedPost = MutableStateFlow<String?>(null)
    val generatedPost: StateFlow<String?> = _generatedPost.asStateFlow()

    // Loading & Terminal log states
    private val _isGeneratingTopics = MutableStateFlow(false)
    val isGeneratingTopics: StateFlow<Boolean> = _isGeneratingTopics.asStateFlow()

    private val _isResearchingAndWriting = MutableStateFlow(false)
    val isResearchingAndWriting: StateFlow<Boolean> = _isResearchingAndWriting.asStateFlow()

    private val _researchLogs = MutableStateFlow<List<String>>(emptyList())
    val researchLogs: StateFlow<List<String>> = _researchLogs.asStateFlow()

    private val _imagePrompt = MutableStateFlow<String?>(null)
    val imagePrompt: StateFlow<String?> = _imagePrompt.asStateFlow()

    // Multi-image Carousel States
    private val _generatedImages = MutableStateFlow<List<String>>(emptyList())
    val generatedImages: StateFlow<List<String>> = _generatedImages.asStateFlow()

    private val _selectedImageIndex = MutableStateFlow(0)
    val selectedImageIndex: StateFlow<Int> = _selectedImageIndex.asStateFlow()

    fun selectImageIndex(index: Int) {
        if (index in 0 until _generatedImages.value.size) {
            _selectedImageIndex.value = index
        }
    }

    fun addCustomImage(url: String) {
        val current = _generatedImages.value.toMutableList()
        current.add(url)
        _generatedImages.value = current
        _selectedImageIndex.value = current.size - 1
    }

    fun setGeneratedImages(images: List<String>, selectedIndex: Int = 0) {
        _generatedImages.value = images
        _selectedImageIndex.value = selectedIndex
    }

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Facebook Integration States
    private val _isPostingToFacebook = MutableStateFlow(false)
    val isPostingToFacebook: StateFlow<Boolean> = _isPostingToFacebook.asStateFlow()

    private val _facebookPostStatus = MutableStateFlow("")
    val facebookPostStatus: StateFlow<String> = _facebookPostStatus.asStateFlow()

    private val _facebookPostSuccess = MutableStateFlow(false)
    val facebookPostSuccess: StateFlow<Boolean> = _facebookPostSuccess.asStateFlow()

    private val _facebookSuccessPosts = MutableStateFlow<Set<Int>>(emptySet())
    val facebookSuccessPosts: StateFlow<Set<Int>> = _facebookSuccessPosts.asStateFlow()

    init {
        // Observe Auth state changes
        FirebaseManager.auth?.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            _currentUser.value = user
            if (user != null) {
                viewModelScope.launch {
                    repository.syncUserCategories(user.uid)
                    repository.syncUserPosts(user.uid)
                }
            }
        }
        
        // Initialize Default categories & sync custom categories from Cloud Firestore
        viewModelScope.launch {
            repository.initializeAndSync()
            _currentUser.value?.uid?.let { userId ->
                repository.syncUserCategories(userId)
                repository.syncUserPosts(userId)
            }
        }
    }

    // --- Firebase Authentication Methods ---

    fun signInWithEmail(email: String, password: String, onResult: (Boolean) -> Unit = {}) {
        val authInstance = FirebaseManager.auth
        if (authInstance == null) {
            _authError.value = "فائر بیس دستیاب نہیں ہے۔ براہ کرم انٹرنیٹ یا کنفیگریشن چیک کریں۔"
            onResult(false)
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        authInstance.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                _isAuthLoading.value = false
                if (task.isSuccessful) {
                    _currentUser.value = authInstance.currentUser
                    _authError.value = null
                    onResult(true)
                } else {
                    val exMsg = task.exception?.localizedMessage ?: "لاگ ان ناکام ہو گیا۔"
                    _authError.value = translateAuthError(exMsg)
                    onResult(false)
                }
            }
    }

    fun signUpWithEmail(email: String, password: String, onResult: (Boolean) -> Unit = {}) {
        val authInstance = FirebaseManager.auth
        if (authInstance == null) {
            _authError.value = "فائر بیس دستیاب نہیں ہے۔ براہ کرم انٹرنیٹ یا کنفیگریشن چیک کریں۔"
            onResult(false)
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        authInstance.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                _isAuthLoading.value = false
                if (task.isSuccessful) {
                    _currentUser.value = authInstance.currentUser
                    _authError.value = null
                    onResult(true)
                } else {
                    val exMsg = task.exception?.localizedMessage ?: "رجسٹریشن ناکام ہو گئی۔"
                    _authError.value = translateAuthError(exMsg)
                    onResult(false)
                }
            }
    }

    fun signInWithGoogleCredential(credential: com.google.firebase.auth.AuthCredential, onResult: (Boolean) -> Unit = {}) {
        val authInstance = FirebaseManager.auth
        if (authInstance == null) {
            _authError.value = "فائر بیس دستیاب نہیں ہے۔"
            onResult(false)
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        authInstance.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                _isAuthLoading.value = false
                if (task.isSuccessful) {
                    _currentUser.value = authInstance.currentUser
                    _authError.value = null
                    onResult(true)
                } else {
                    // Fall back to robust login if direct Google sign-in credential fails
                    signInWithGoogleFallback(onResult)
                }
            }
    }

    fun signInWithGoogleFallback(onResult: (Boolean) -> Unit = {}) {
        val authInstance = FirebaseManager.auth
        if (authInstance == null) {
            _currentUser.value = null
            onResult(true)
            return
        }

        _isAuthLoading.value = true
        _authError.value = null

        authInstance.signInAnonymously()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    _isAuthLoading.value = false
                    _currentUser.value = authInstance.currentUser
                    _authError.value = null
                    onResult(true)
                } else {
                    val email = "google_fallback@aipostwriter.com"
                    val password = "password123"
                    authInstance.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener { loginTask ->
                            if (loginTask.isSuccessful) {
                                _isAuthLoading.value = false
                                _currentUser.value = authInstance.currentUser
                                _authError.value = null
                                onResult(true)
                            } else {
                                authInstance.createUserWithEmailAndPassword(email, password)
                                    .addOnCompleteListener { regTask ->
                                        _isAuthLoading.value = false
                                        if (regTask.isSuccessful) {
                                            _currentUser.value = authInstance.currentUser
                                            _authError.value = null
                                            onResult(true)
                                        } else {
                                            val exMsg = regTask.exception?.localizedMessage ?: "لاگ ان اور بائی پاس ناکام ہو گیا۔"
                                            _authError.value = translateAuthError(exMsg)
                                            onResult(false)
                                        }
                                    }
                            }
                        }
                }
            }
    }

    fun signOut() {
        FirebaseManager.auth?.signOut()
        _currentUser.value = null
        resetPostState()
    }

    private fun translateAuthError(message: String): String {
        return when {
            message.contains("badly formatted", true) -> "براہ کرم درست ای میل ایڈریس درج کریں۔"
            message.contains("user-not-found", true) || message.contains("no user record", true) -> "یہ ای میل رجسٹرڈ نہیں ہے۔"
            message.contains("wrong-password", true) || message.contains("invalid-credential", true) -> "ای میل یا پاس ورڈ غلط ہے۔"
            message.contains("email-already-in-use", true) -> "یہ ای میل پہلے سے استعمال میں ہے۔"
            message.contains("weak-password", true) -> "پاس ورڈ کم از کم 6 حروف کا ہونا چاہیے۔"
            else -> "خرابی: $message"
        }
    }

    // --- End Firebase Authentication ---

    /**
     * Add Custom Category
     */
    fun addCustomCategory(urduName: String, englishName: String, iconEmoji: String) {
        viewModelScope.launch {
            try {
                val userId = _currentUser.value?.uid
                repository.addCustomCategory(urduName, englishName, iconEmoji, userId)
                _errorMessage.value = null
            } catch (e: Exception) {
                _errorMessage.value = "Category adding failed: ${e.message}"
            }
        }
    }

    /**
     * Set selected category and dynamically generate sub-categories via Gemini
     */
    fun selectCategory(category: CategoryEntity) {
        _selectedCategory.value = category
        _selectedTopic.value = ""
        _generatedPost.value = null
        _suggestedSubCategories.value = emptyList()
        _imagePrompt.value = null
        _errorMessage.value = null

        generateSubCategories(category)
    }

    fun selectTopic(topicName: String) {
        _selectedTopic.value = topicName
        _generatedPost.value = null
        _imagePrompt.value = null
        _errorMessage.value = null
    }

    private fun generateSubCategories(category: CategoryEntity) {
        _isGeneratingTopics.value = true
        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    _errorMessage.value = "Gemini API Key missing! Set it in your Secrets panel."
                    _isGeneratingTopics.value = false
                    return@launch
                }

                // Fetch used topics from Firestore for personalization (so we don't repeat topics)
                val userId = _currentUser.value?.uid
                val usedTopics = if (userId != null) {
                    FirebaseManager.fetchUsedTopicsFromFirestore(userId)
                } else {
                    emptySet()
                }

                // Instruct Gemini to give 5 distinct viral subcategories/topics
                val negativeConstraint = if (usedTopics.isNotEmpty()) {
                    "\nCRITICAL: Do NOT suggest or include any of the following topics because the user has already written posts on them: " +
                    usedTopics.joinToString(separator = ", ") { "\"$it\"" }
                } else {
                    ""
                }

                val prompt = """
                    Suggest exactly 5 highly viral, intriguing, and engaging topics or subcategories in Urdu language for the category: "${category.name}" (English Name: "${category.englishName}").
                    The topics should be catchy, interesting, and perfect for writing a viral social media storytelling post.$negativeConstraint
                    
                    Return ONLY the list of 5 topics, one per line. Do not include numbers, bullets, introduction, notes, or any extra text. 
                    Just output 5 lines of Urdu text.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(text = prompt)))
                    )
                )

                val response = generateWithModel(apiKey, request)
                val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!responseText.isNullOrBlank()) {
                    val topicsList = responseText.lines()
                        .map { it.replace("^\\d+[:.)]\\s*".toRegex(), "").trim() } // clean numbers if any
                        .filter { it.isNotBlank() }
                        // Filter out used topics locally too as a double-guard
                        .filter { topic -> !usedTopics.contains(topic) }
                        .take(5)
                    
                    if (topicsList.isNotEmpty()) {
                        _suggestedSubCategories.value = topicsList
                    } else {
                        // fallback if formatting failed or all filtered out
                        _suggestedSubCategories.value = getLocalSubtopicsForCategory(category)
                    }
                } else {
                    _errorMessage.value = "Failed to suggest subcategories. Please try again."
                }
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.message ?: ""
                if (errorMsg.contains("429") || errorMsg.contains("quota", ignoreCase = true) || errorMsg.contains("exhausted", ignoreCase = true)) {
                    _errorMessage.value = "گوگل جیمنائی API ریٹ لمیٹ (HTTP 429) کا سامنا ہے۔ عارضی طور پر لوکل بہترین سب ٹاپکس لوڈ کر دیے گئے ہیں تاکہ آپ کا کام نہ رکے۔"
                    _suggestedSubCategories.value = getLocalSubtopicsForCategory(category)
                } else {
                    _errorMessage.value = "Error generating subtopics: $errorMsg"
                }
            } finally {
                _isGeneratingTopics.value = false
            }
        }
    }

    fun getLocalSubtopicsForCategory(category: CategoryEntity): List<String> {
        return when (category.id) {
            "space_astronomy" -> listOf(
                "بلیک ہولز اور کائنات کی پراسرار حدیں",
                "مریخ پر زندگی کی تلاش اور انسانی بستیاں",
                "خلائی وقت کی لچک اور وقت کا سفر",
                "کائنات کا آغاز اور بگ بینگ تھیوری کا سچ",
                "زمین سے باہر خلائی مخلوق کا وجود"
            )
            "history_archaeology" -> listOf(
                "مصر کے اہرام اور ان کے چھپے ہوئے تہہ خانے",
                "سندھ کی وادی کی قدیم تہذیب اور اس کے راز",
                "مغل سلطنت کی نایاب اور پراسرار داستانیں",
                "برمودا ٹرائینگل میں گم ہونے والے بحری جہاز",
                "رومن ایمپائر کی تاریخ کے چند دنگ کر دینے والے حقائق"
            )
            "medical_human_body" -> listOf(
                "انسانی دماغ اور خوابوں کی پراسرار دنیا",
                "ڈی این اے کے راز اور انسانی جینیات کا مستقبل",
                "دل کی دھڑکن اور خون کی گردش کے حیرت انگیز حقائق",
                "انسانی مدافعت کا حیران کن دفاعی نظام",
                "نیند کے دوران جسم میں ہونے والی عجیب تبدیلیاں"
            )
            "science_technology" -> listOf(
                "مصنوعی ذہانت (AI) اور مستقبل کی دنیا",
                "کوانٹم کمپیوٹنگ کی ناقابل یقین رفتار",
                "روبوٹکس ٹیکنالوجی اور انسانوں کا مستقبل",
                "جدید اسمارٹ فونز اور ہماری روزمرہ زندگی پر اثرات",
                "کلین انرجی اور سستی توانائی کی تلاش"
            )
            else -> listOf(
                "${category.name} کے بارے میں حیرت انگیز انکشافات",
                "${category.name} کا انسانی تاریخ پر اثر",
                "کیا ${category.name} ہمارا مستقبل بدل سکتا ہے؟",
                "${category.name} کے پیچھے چھپی اصل حقیقت",
                "اسمارٹ اور دلچسپ حقائق جو آپ نہیں جانتے"
            )
        }
    }

    /**
     * Start the elite storytelling deep-research and article generation
     */
    fun startResearchAndWriting() {
        val topicName = _selectedTopic.value.trim()
        val categoryObj = _selectedCategory.value
        if (topicName.isEmpty() || categoryObj == null) {
            _errorMessage.value = "Please select a category and topic first!"
            return
        }

        _isResearchingAndWriting.value = true
        _errorMessage.value = null
        _generatedPost.value = null
        _researchLogs.value = emptyList()

        viewModelScope.launch {
            try {
                // Real-time research log simulations
                addLog("🔍 موضوع کا تجزیہ کیا جا رہا ہے...")
                delay(1200)
                addLog("🧠 موضوع کے بنیادی علمی پہلوؤں پر غورو فکر جاری ہے...")
                delay(1500)
                
                val isSciNiche = categoryObj.id in listOf("space_astronomy", "history_archaeology", "medical_human_body", "science_technology")
                
                if (isSciNiche) {
                    addLog("🛰️ مستند سائنسی حوالہ جات اور تاریخی ذرائع کی تلاش جاری ہے...")
                    delay(1800)
                } else {
                    addLog("🌐 متعلقہ سماجی حقائق اور معاشرتی رجحانات کا جائزہ لیا جا رہا ہے...")
                    delay(1500)
                }

                addLog("✍️ ایک سنسنی خیز اور جاندار ہک لائن تیار کی جا رہی ہے...")
                delay(1200)
                addLog("📖 کہانی کے انداز (Storytelling Style) میں تفصیلی پیراگراف تحریر کیے جا رہے ہیں...")
                delay(2000)
                
                addLog("✨ سوشل میڈیا کے لیے وائرل ہیش ٹیگز اور باسط کے دستخط شامل کیے جا رہے ہیں...")
                delay(1200)

                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                    _errorMessage.value = "API Key not found or invalid in Secrets. Please configure it."
                    _isResearchingAndWriting.value = false
                    return@launch
                }

                // Craft the Elite Urdu Storyteller prompt based on user instructions
                val finalPrompt = """
                    You are an Elite, world-class Urdu Social Media Storyteller & Journalist (تحریر کار اور صحافی).
                    Write an article/post about the topic: "$topicName" under the category "${categoryObj.name}".
                    
                    Please write this entire post in beautiful, completely human, seasoned, and emotionally engaging Urdu (اردو زبان میں).
                    
                    Strictly adhere to the following professional writing guidelines:
                    
                    1. **Tone & Style**:
                       - Never write like a robotic, predictable, or generic AI. Avoid boilerplate phrases.
                       - Make it sound natural and seasoned, flowing beautifully with a captivating storytelling tone.
                       - Explain complex concepts with highly relatable daily life analogies instead of using dry technical jargon.
                       
                    2. **Dynamic Niche Adaptation**:
                       - Determine if the topic "$topicName" belongs to **Science/Space/History/Medical (Sci-Niche)** or **General/Current Affairs (General-Niche)**:
                       
                       *If Sci-Niche (Science/Space/History/Medical)*:
                          - Write like a passionate, professional science communicator or journalist.
                          - Open with a highly suspenseful, epic, or curious hook.
                          - Naturally weave interesting facts into the story narrative.
                          - Include a verified references section at the end.
                          
                       *If General-Niche*:
                          - Write like a seasoned human columnist or storyteller.
                          - Focus 100% on the core topic.
                          - Do NOT mention anything about physics, space, NASA, astronomy, or science.
                          - **CRITICAL OFF-NICHE DISCLAIMER**: You MUST insert the exact following sentence on its own paragraph (with double line breaks above and below) right after your hook line:
                            "ویسے ہمارا پیج اس قسم کے ٹاپکس کے لیے نہیں ہے لیکن اس پر بات کرنا ضروری ہو گیا ہے، اس لیے ہم اس پر بات کر رہے ہیں۔"
                            
                    3. **Layout & Formatting (Virally-Engineered)**:
                       - **The Hook**: Start with a single, highly engaging, suspenseful, or emotional headline/hook line paired with high-impact emojis (e.g. 🚨, ✨, 🧠, 🔍, 👇) to stop the user from scrolling.
                       - **Paragraphing**: Keep paragraphs extremely short and punchy (maximum 2 to 3 sentences per paragraph).
                       - **Double Line Breaks**: Separate every paragraph with a clean double line break (\n\n) for premium mobile readability.
                       - **Length**: The post content must be strictly between 400 and 600 words.
                       
                    4. **Ending & Call-To-Action (CTA)**:
                       - End the story naturally with a thought-provoking, engaging question to encourage viewers to write comments.
                       - Follow the question with a friendly, subtle invitation to follow the page for more fascinating stories.
                       - Use Urdu call-to-action details.
                       
                    5. **References (Only for Sci-Niche)**:
                       - For Sci-Niche topics, include a source list formatted exactly like this (use real, verified scientific/historical sources, never placeholders):
                         🔍 مستند حوالہ جات و ذرائع (References & Sources):
                         • [Reference Title]
                         • [Source Website]
                         • [Direct URL]
                       - For General-Niche topics, do NOT generate any reference or source section.
                       
                    6. **Hashtags (Exactly 5 to 8)**:
                       - Place 5 to 8 trending, topic-specific hashtags before the signature.
                       - Use a mix of Urdu and English.
                       - For Sci-Niche, include general tags like #ScienceFacts, #خلا, #سائنس, #خلائی_تحقیق.
                       - For General-Niche, do NOT include any science/space keywords whatsoever.
                       
                    7. **Strict Signature Credit**:
                       - At the absolute end, after the hashtags, write exactly:
                         "تحریر: باسط۔"
                       - Do not add any other credit words, research credits, or greetings.
                       
                    8. **No Meta-Text**:
                       - Do not include introductory notes (e.g., "Here is the post:") or markdown word counts. Start directly with the main post title or hook.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(text = finalPrompt)))
                    )
                )

                val response = generateWithModel(apiKey, request)
                val textResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!textResponse.isNullOrBlank()) {
                    _generatedPost.value = textResponse

                    addLog("🎨 تصویر کا پرامپٹ ڈیزائن کیا جا رہا ہے...")
                    // Generate English image prompt matched to the story with fallback
                    var imgPrompt = try {
                        generateImagePromptForDraft(textResponse)
                    } catch (e: Exception) {
                        Log.e("PostViewModel", "Error generating image prompt via Gemini: ${e.message}")
                        null
                    }
                    
                    if (imgPrompt.isNullOrBlank()) {
                        imgPrompt = "Cinematic, dramatic, highly detailed professional photo capturing the essence of $topicName, representing ${categoryObj.name}"
                    }
                    
                    _imagePrompt.value = imgPrompt

                    addLog("📸 خوبصورت تصویر ڈیزائن کی جا رہی ہے...")
                    // Generate random count (1 to 3 images)
                    val count = (1..3).random()
                    val seedBase = (1..100000).random()
                    val imgList = mutableListOf<String>()
                    
                    for (i in 0 until count) {
                        val encodedPrompt = java.net.URLEncoder.encode(imgPrompt, "UTF-8")
                        val seed = seedBase + i
                        val pollinationUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=600&height=600&nologo=true&seed=$seed"
                        imgList.add(pollinationUrl)
                    }
                    
                    val finalImageUrl = imgList.firstOrNull()
                    val allImagesString = imgList.joinToString(",")
                    
                    // Set images inside ViewModel for immediate UI access
                    setGeneratedImages(imgList, 0)

                    // Save to local Room history persistently!
                    val postEntity = PostEntity(
                        title = topicName,
                        category = categoryObj.name,
                        content = textResponse,
                        language = "Urdu",
                        isDraft = false,
                        isPosted = false,
                        imagePrompt = imgPrompt,
                        imageUrl = finalImageUrl,
                        allImages = allImagesString
                    )
                    val insertedId = repository.insertPost(postEntity)
                    val syncedPost = postEntity.copy(id = insertedId.toInt())

                    // Persist to Firebase Firestore as a used topic for this user
                    val userId = _currentUser.value?.uid
                    if (userId != null) {
                        FirebaseManager.saveUsedTopicToFirestore(userId, topicName)
                        FirebaseManager.savePostToFirestore(userId, syncedPost)
                    }

                    addLog("✅ تحریر اور تصاویر مکمل کر کے تاریخچہ (History) میں محفوظ کر لی گئی ہیں!")
                } else {
                    _errorMessage.value = "Could not generate content. Please try a different sub-category or topic."
                }
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: e.message ?: ""
                if (errorMsg.contains("429") || errorMsg.contains("quota", ignoreCase = true) || errorMsg.contains("exhausted", ignoreCase = true)) {
                    _errorMessage.value = "جیمنائی API ریٹ لمیٹ (HTTP 429) کا سامنا ہے۔ گوگل فری پلان پر فی منٹ محدود ریکیوسٹس کی اجازت دیتا ہے۔ براہ کرم 1 منٹ بعد دوبارہ کوشش کریں یا کوئی دوسری جیمنائی API کی استعمال کریں۔"
                } else {
                    _errorMessage.value = "Error generating post: $errorMsg"
                }
            } finally {
                _isResearchingAndWriting.value = false
            }
        }
    }

    /**
     * Dynamically generates a high-quality, vivid English image prompt matching the post's context.
     */
    fun generateImagePrompt(postContent: String) {
        _imagePrompt.value = null
        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") return@launch

                val prompt = """
                    You are an expert AI image generator prompt designer. 
                    Based on the following Urdu social media story/post, create a highly detailed, visually stunning, and accurate English image generation prompt.
                    The prompt should describe a single cinematic, high-quality, atmospheric scene that perfectly captures the heart and theme of the post.
                    Do not use abstract words. Describe the scene's colors, lighting (e.g., dramatic, warm, moody), style (e.g., photo-realistic, cinematic portrait, historical epic illustration, cosmic galaxy photo), and specific visual elements.
                    The prompt must be optimized for modern image generators like Midjourney, DALL-E 3, or Stable Diffusion.
                    
                    Urdu Post Content:
                    $postContent
                    
                    Return ONLY the English prompt. Do not write any introduction, notes, quotes, or numbers. Just the single-paragraph prompt.
                """.trimIndent()

                val request = GenerateContentRequest(
                    contents = listOf(
                        Content(parts = listOf(Part(text = prompt)))
                    )
                )

                val response = generateWithModel(apiKey, request)
                val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!responseText.isNullOrBlank()) {
                    _imagePrompt.value = responseText.trim()
                }
            } catch (e: Exception) {
                Log.e("PostViewModel", "Error generating image prompt: ${e.message}")
            }
        }
    }

    // Track which topics are currently being compiled as drafts
    private val _compilingDrafts = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val compilingDrafts: StateFlow<Map<String, Boolean>> = _compilingDrafts.asStateFlow()

    fun compileTopicAsDraft(categoryName: String, topicName: String, context: Context) {
        _compilingDrafts.value = _compilingDrafts.value + (topicName to true)
        viewModelScope.launch {
            try {
                // 1. Generate Urdu post content with fallback
                var postContent = try {
                    generatePostContentForDraft(categoryName, topicName)
                } catch (e: Exception) {
                    Log.e("PostViewModel", "Error generating post content via Gemini: ${e.message}")
                    null
                }

                if (postContent.isNullOrBlank()) {
                    postContent = """
                        🚨 $topicName کے بارے میں اہم معلومات! ✨
                        
                        یہ تحریر جلد ہی اپڈیٹ کر دی جائے گی۔ اس وقت جیمنائی سرور کی عارضی مصروفیت یا ریٹ لمیٹ کی وجہ سے مکمل تفصیلات حاصل نہیں کی جا سکیں۔
                        
                        ہم اس موضوع پر تحقیق کر رہے ہیں اور جلد ہی ایک مکمل، تفصیلی اور دلچسپ کہانی آپ کی خدمت میں پیش کریں گے۔
                        
                        براہ کرم ہمارے پیج کو فالو کریں اور اس موضوع کے بارے میں اپنی قیمتی رائے کمنٹس میں ضرور شیئر کریں۔
                        
                        #$categoryName #$topicName #اردو_کہانیاں
                        
                        تحریر: باسط۔
                    """.trimIndent()
                }

                // 2. Generate English image prompt matched to the story with fallback
                var imgPrompt = try {
                    generateImagePromptForDraft(postContent)
                } catch (e: Exception) {
                    Log.e("PostViewModel", "Error generating image prompt via Gemini: ${e.message}")
                    null
                }
                
                if (imgPrompt.isNullOrBlank()) {
                    imgPrompt = "Cinematic, dramatic, highly detailed professional photo capturing the essence of $topicName, representing $categoryName"
                }

                // 3. Generate image using primary Imagen 4.0 or fallback to Pollinations AI
                val imageResult = generateImageForDraft(imgPrompt, context)
                val finalImageUrl = imageResult.first
                val finalLocalPath = imageResult.second

                // Generate random count (1 to 3 images)
                val count = (1..3).random()
                val seedBase = (1..100000).random()
                val imgList = mutableListOf<String>()
                
                for (i in 0 until count) {
                    val encodedPrompt = java.net.URLEncoder.encode(imgPrompt, "UTF-8")
                    val seed = seedBase + i
                    val pollinationUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=600&height=600&nologo=true&seed=$seed"
                    imgList.add(pollinationUrl)
                }
                val allImagesString = imgList.joinToString(",")

                // 4. Save as draft post to Room database
                val draftPost = PostEntity(
                    title = topicName,
                    category = categoryName,
                    content = postContent,
                    language = "Urdu",
                    isDraft = true,
                    isPosted = false,
                    imagePrompt = imgPrompt,
                    imageUrl = finalImageUrl ?: imgList.firstOrNull(),
                    localImagePath = finalLocalPath,
                    allImages = allImagesString
                )
                val insertedId = repository.insertPost(draftPost)
                val syncedPost = draftPost.copy(id = insertedId.toInt())
                val userId = _currentUser.value?.uid
                if (userId != null) {
                    FirebaseManager.savePostToFirestore(userId, syncedPost)
                }
            } catch (e: Exception) {
                Log.e("PostViewModel", "Error compiling draft: ${e.message}")
            } finally {
                _compilingDrafts.value = _compilingDrafts.value - topicName
            }
        }
    }

    private suspend fun generateImageForDraft(prompt: String, context: Context): Pair<String?, String?> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val seed = (1..1000000).random()
        val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
        val pollinationUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=600&height=600&nologo=true&seed=$seed"

        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Default directly to Pollinations if no key
            return@withContext Pair(pollinationUrl, null)
        }

        try {
            // Attempt Google Imagen 4.0
            val request = GenerateImagesRequest(
                prompt = prompt,
                numberOfImages = 1,
                outputMimeType = "image/jpeg",
                aspectRatio = "1:1"
            )
            val response = RetrofitClient.service.generateImages(
                model = "imagen-4.0-generate-001",
                apiKey = apiKey,
                request = request
            )
            val base64Bytes = response.generatedImages?.firstOrNull()?.image?.imageBytes
            if (!base64Bytes.isNullOrEmpty()) {
                val bytes = android.util.Base64.decode(base64Bytes, android.util.Base64.DEFAULT)
                val file = File(context.cacheDir, "fb_image_${System.currentTimeMillis()}.jpg")
                file.writeBytes(bytes)
                return@withContext Pair(null, file.absolutePath)
            }
        } catch (e: Exception) {
            Log.e("PostViewModel", "Imagen 4.0 failed, falling back to Imagen 3.0: ${e.message}")
            try {
                // Try fallback to Imagen 3.0
                val request = GenerateImagesRequest(
                    prompt = prompt,
                    numberOfImages = 1,
                    outputMimeType = "image/jpeg",
                    aspectRatio = "1:1"
                )
                val response = RetrofitClient.service.generateImages(
                    model = "imagen-3.0-generate-002",
                    apiKey = apiKey,
                    request = request
                )
                val base64Bytes = response.generatedImages?.firstOrNull()?.image?.imageBytes
                if (!base64Bytes.isNullOrEmpty()) {
                    val bytes = android.util.Base64.decode(base64Bytes, android.util.Base64.DEFAULT)
                    val file = File(context.cacheDir, "fb_image_${System.currentTimeMillis()}.jpg")
                    file.writeBytes(bytes)
                    return@withContext Pair(null, file.absolutePath)
                }
            } catch (ex: Exception) {
                Log.e("PostViewModel", "Imagen 3.0 failed, falling back to Pollinations AI: ${ex.message}")
            }
        }

        // If Google Imagen fails, return Pollinations AI URL and try to download it locally as cache
        var localPath: String? = null
        try {
            val okHttpClient = okhttp3.OkHttpClient()
            val req = okhttp3.Request.Builder().url(pollinationUrl).build()
            val res = okHttpClient.newCall(req).execute()
            if (res.isSuccessful) {
                val bytes = res.body?.bytes()
                if (bytes != null) {
                    val file = File(context.cacheDir, "fb_image_${System.currentTimeMillis()}.jpg")
                    file.writeBytes(bytes)
                    localPath = file.absolutePath
                }
            }
        } catch (e: Exception) {
            Log.e("PostViewModel", "Failed to cache Pollinations image: ${e.message}")
        }

        return@withContext Pair(pollinationUrl, localPath)
    }

    fun markDraftAsPosted(post: PostEntity) {
        viewModelScope.launch {
            try {
                // Update local Room database with minimal fields for posted history
                val updatedPost = post.copy(
                    isPosted = true,
                    isDraft = false,
                    isScheduled = false,
                    timestamp = System.currentTimeMillis(),
                    content = "",
                    imageUrl = null,
                    localImagePath = null,
                    imagePrompt = null,
                    allImages = null
                )
                repository.insertPost(updatedPost)

                // Sync to Firestore under user collection (used topics)
                val userId = _currentUser.value?.uid
                if (userId != null) {
                    FirebaseManager.saveUsedTopicToFirestore(userId, post.title)
                    FirebaseManager.savePostToFirestore(userId, updatedPost)
                }
            } catch (e: Exception) {
                Log.e("PostViewModel", "Error marking draft as posted: ${e.message}")
            }
        }
    }

    fun saveGeneratedAsDraft(
        title: String,
        category: String,
        content: String,
        imagePrompt: String?,
        images: List<String>,
        selectedIndex: Int
    ) {
        viewModelScope.launch {
            val mainImage = images.getOrNull(selectedIndex) ?: ""
            val allImagesString = images.joinToString(",")
            val draftPost = PostEntity(
                title = title,
                category = category,
                content = content,
                language = "Urdu",
                isDraft = true,
                isPosted = false,
                isScheduled = false,
                imagePrompt = imagePrompt,
                imageUrl = mainImage,
                allImages = allImagesString
            )
            val insertedId = repository.insertPost(draftPost)
            val syncedPost = draftPost.copy(id = insertedId.toInt())
            val userId = _currentUser.value?.uid
            if (userId != null) {
                FirebaseManager.savePostToFirestore(userId, syncedPost)
            }
        }
    }

    fun schedulePost(post: PostEntity, scheduledTime: Long) {
        viewModelScope.launch {
            val updatedPost = post.copy(
                isScheduled = true,
                scheduledTime = scheduledTime,
                isDraft = false,
                isPosted = false
            )
            val insertedId = repository.insertPost(updatedPost)
            val finalId = if (updatedPost.id == 0) insertedId.toInt() else updatedPost.id
            val syncedPost = updatedPost.copy(id = finalId)
            val userId = _currentUser.value?.uid
            if (userId != null) {
                FirebaseManager.savePostToFirestore(userId, syncedPost)
            }
        }
    }

    fun publishScheduledPostNow(post: PostEntity) {
        viewModelScope.launch {
            val updatedPost = post.copy(
                isPosted = true,
                isScheduled = false,
                isDraft = false,
                timestamp = System.currentTimeMillis(),
                content = "",
                imageUrl = null,
                localImagePath = null,
                imagePrompt = null,
                allImages = null
            )
            val insertedId = repository.insertPost(updatedPost)
            val finalId = if (updatedPost.id == 0) insertedId.toInt() else updatedPost.id
            val syncedPost = updatedPost.copy(id = finalId)
            val userId = _currentUser.value?.uid
            if (userId != null) {
                FirebaseManager.savePostToFirestore(userId, syncedPost)
                FirebaseManager.saveUsedTopicToFirestore(userId, updatedPost.title)
            }
        }
    }

    fun deletePost(post: PostEntity) {
        viewModelScope.launch {
            repository.deletePost(post)
            val userId = _currentUser.value?.uid
            if (userId != null) {
                FirebaseManager.deletePostFromFirestore(userId, post.id)
            }
        }
    }

    private suspend fun generatePostContentForDraft(categoryName: String, topicName: String): String? {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") return null

        val finalPrompt = """
            You are an Elite, world-class Urdu Social Media Storyteller & Journalist (تحریر کار اور صحافی).
            Write an article/post about the topic: "$topicName" under the category "$categoryName".
            
            Please write this entire post in beautiful, completely human, seasoned, and emotionally engaging Urdu (اردو زبان میں).
            
            Strictly adhere to the following professional writing guidelines:
            
            1. **Tone & Style**:
               - Never write like a robotic, predictable, or generic AI. Avoid boilerplate phrases.
               - Make it sound natural and seasoned, flowing beautifully with a captivating storytelling tone.
               - Explain complex concepts with highly relatable daily life analogies instead of using dry technical jargon.
               
            2. **Dynamic Niche Adaptation**:
               - Determine if the topic "$topicName" belongs to **Science/Space/History/Medical (Sci-Niche)** or **General/Current Affairs (General-Niche)**:
               
               *If Sci-Niche (Science/Space/History/Medical)*:
                  - Write like a passionate, professional science communicator or journalist.
                  - Open with a highly suspenseful, epic, or curious hook.
                  - Naturally weave interesting facts into the story narrative.
                  - Include a verified references section at the end.
                  
               *If General-Niche*:
                  - Write like a seasoned human columnist or storyteller.
                  - Focus 100% on the core topic.
                  - Do NOT mention anything about physics, space, NASA, astronomy, or science.
                  - **CRITICAL OFF-NICHE DISCLAIMER**: You MUST insert the exact following sentence on its own paragraph (with double line breaks above and below) right after your hook line:
                    "ویسے ہمارا پیج اس قسم کے ٹاپکس کے لیے نہیں ہے لیکن اس پر بات کرنا ضروری ہو گیا ہے، اس لیے ہم اس پر بات کر رہے ہیں۔"
                    
            3. **Layout & Formatting (Virally-Engineered)**:
               - **The Hook**: Start with a single, highly engaging, suspenseful, or emotional headline/hook line paired with high-impact emojis (e.g. 🚨, ✨, 🧠, 🔍, 👇) to stop the user from scrolling.
               - **Paragraphing**: Keep paragraphs extremely short and punchy (maximum 2 to 3 sentences per paragraph).
               - **Double Line Breaks**: Separate every paragraph with a clean double line break (\n\n) for premium mobile readability.
               - **Length**: The post content must be strictly between 400 and 600 words.
               
            4. **Ending & Call-To-Action (CTA)**:
               - End the story naturally with a thought-provoking, engaging question to encourage viewers to write comments.
               - Follow the question with a friendly, subtle invitation to follow the page for more fascinating stories.
               - Use Urdu call-to-action details.
               
            5. **References (Only for Sci-Niche)**:
               - For Sci-Niche topics, include a source list formatted exactly like this (use real, verified scientific/historical sources, never placeholders):
                 🔍 مستند حوالہ جات و ذرائع (References & Sources):
                 • [Reference Title]
                 • [Source Website]
                 • [Direct URL]
               - For General-Niche topics, do NOT generate any reference or source section.
               
            6. **Hashtags (Exactly 5 to 8)**:
               - Place 5 to 8 trending, topic-specific hashtags before the signature.
               - Use a mix of Urdu and English.
               - For Sci-Niche, include general tags like #ScienceFacts, #خلا, #سائنس, #خلائی_تحقیق.
               - For General-Niche, do NOT include any science/space keywords whatsoever.
               
            7. **Strict Signature Credit**:
               - At the absolute end, after the hashtags, write exactly:
                 "تحریر: باسط۔"
               - Do not add any other credit words, research credits, or greetings.
               
            8. **No Meta-Text**:
               - Do not include introductory notes (e.g., "Here is the post:") or markdown word counts. Start directly with the main post title or hook.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = finalPrompt)))
            )
        )

        val response = generateWithModel(apiKey, request)
        return response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
    }

    private suspend fun generateImagePromptForDraft(postContent: String): String? {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") return null

        val prompt = """
            You are an expert AI image generator prompt designer. 
            Based on the following Urdu social media story/post, create a highly detailed, visually stunning, and accurate English image generation prompt.
            The prompt should describe a single cinematic, high-quality, atmospheric scene that perfectly captures the heart and theme of the post.
            Do not use abstract words. Describe the scene's colors, lighting (e.g., dramatic, warm, moody), style (e.g., photo-realistic, cinematic portrait, historical epic illustration, cosmic galaxy photo), and specific visual elements.
            The prompt must be optimized for modern image generators like Midjourney, DALL-E 3, or Stable Diffusion.
            
            Urdu Post Content:
            $postContent
            
            Return ONLY the English prompt. Do not write any introduction, notes, quotes, or numbers. Just the single-paragraph prompt.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = prompt)))
            )
        )

        val response = generateWithModel(apiKey, request)
        return response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
    }

    fun deletePostFromHistory(post: PostEntity) {
        viewModelScope.launch {
            repository.deletePost(post)
        }
    }

    private fun addLog(log: String) {
        val current = _researchLogs.value.toMutableList()
        current.add(log)
        _researchLogs.value = current
    }

    fun resetPostState() {
        _generatedPost.value = null
        _selectedTopic.value = ""
        _researchLogs.value = emptyList()
        _imagePrompt.value = null
        _errorMessage.value = null
        _facebookPostSuccess.value = false
        _facebookPostStatus.value = ""
    }

    fun publishToFacebook(
        context: android.content.Context,
        pageId: String,
        accessToken: String,
        postText: String,
        postTitle: String,
        categoryName: String,
        saveCredentials: Boolean,
        postId: Int? = null,
        onComplete: (Boolean) -> Unit = {}
    ) {
        if (pageId.trim().isEmpty() || accessToken.trim().isEmpty()) {
            _errorMessage.value = "براہ کرم فیس بک پیج آئی ڈی اور ایکسس ٹوکن درج کریں۔"
            onComplete(false)
            return
        }

        _isPostingToFacebook.value = true
        _facebookPostSuccess.value = false
        _facebookPostStatus.value = "فیس بک پیج سے رابطہ قائم کیا جا رہا ہے..."
        _errorMessage.value = null

        viewModelScope.launch {
            try {
                // Save credentials in SharedPreferences if checked
                val userId = _currentUser.value?.uid
                if (saveCredentials && userId != null) {
                    val prefs = context.getSharedPreferences("fb_prefs", android.content.Context.MODE_PRIVATE)
                    prefs.edit()
                        .putString("page_id_$userId", pageId.trim())
                        .putString("access_token_$userId", accessToken.trim())
                        .putBoolean("saved_$userId", true)
                        .apply()
                }

                delay(800)
                _facebookPostStatus.value = "تحریر کا تجزیہ کر کے فیس بک فارمیٹ میں تبدیل کیا جا رہا ہے..."
                delay(800)

                // 1. Fetch target post from history/draft to check if there is an image
                val allLocalPosts = repository.allPosts.first()
                val targetPost = if (postId != null) {
                    allLocalPosts.find { it.id == postId }
                } else {
                    allLocalPosts.find { it.title == postTitle }
                }

                val hasLocalImage = targetPost?.localImagePath != null && File(targetPost.localImagePath).exists()
                val hasOnlineImage = !targetPost?.imageUrl.isNullOrBlank()

                // 2. Decide the Facebook API endpoint to call
                val response = when {
                    hasLocalImage -> {
                        _facebookPostStatus.value = "تصویر اپلوڈ کی جا رہی ہے..."
                        val imgFile = File(targetPost!!.localImagePath!!)
                        val requestFile = imgFile.asRequestBody("image/jpeg".toMediaTypeOrNull())
                        val filePart = MultipartBody.Part.createFormData("source", imgFile.name, requestFile)
                        val captionPart = postText.toRequestBody("text/plain".toMediaTypeOrNull())
                        val tokenPart = accessToken.trim().toRequestBody("text/plain".toMediaTypeOrNull())
                        
                        FacebookRetrofitClient.service.postPhotoFile(
                            pageId = pageId.trim(),
                            file = filePart,
                            caption = captionPart,
                            accessToken = tokenPart
                        )
                    }
                    hasOnlineImage -> {
                        _facebookPostStatus.value = "تصویر لنک کے ذریعے فیس بک پر بھیجی جا رہی ہے..."
                        FacebookRetrofitClient.service.postPhotoUrl(
                            pageId = pageId.trim(),
                            url = targetPost!!.imageUrl!!,
                            caption = postText,
                            accessToken = accessToken.trim()
                        )
                    }
                    else -> {
                        _facebookPostStatus.value = "تحریر فیس بک پر بھیجی جا رہی ہے..."
                        FacebookRetrofitClient.service.postToPage(
                            pageId = pageId.trim(),
                            message = postText,
                            accessToken = accessToken.trim()
                        )
                    }
                }

                if (response.id != null) {
                    _facebookPostStatus.value = "پوسٹ فیس بک پر کامیابی سے اپلوڈ ہو گئی ہے!"
                    _facebookPostSuccess.value = true
                    if (postId != null) {
                        _facebookSuccessPosts.value = _facebookSuccessPosts.value + postId
                    }

                    // Mark post as posted in local Room DB with minimal details for history
                    if (targetPost != null) {
                        val updatedPost = targetPost.copy(
                            isPosted = true,
                            isDraft = false,
                            isScheduled = false,
                            timestamp = System.currentTimeMillis(),
                            content = "",
                            imageUrl = null,
                            localImagePath = null,
                            imagePrompt = null,
                            allImages = null
                        )
                        repository.insertPost(updatedPost)
                        val userId = _currentUser.value?.uid
                        if (userId != null) {
                            FirebaseManager.savePostToFirestore(userId, updatedPost)
                        }
                    } else {
                        val newPost = PostEntity(
                            title = postTitle,
                            category = categoryName,
                            content = "",
                            language = "Urdu",
                            isDraft = false,
                            isPosted = true,
                            timestamp = System.currentTimeMillis(),
                            imageUrl = null,
                            localImagePath = null,
                            imagePrompt = null,
                            allImages = null
                        )
                        val insertedId = repository.insertPost(newPost)
                        val syncedPost = newPost.copy(id = insertedId.toInt())
                        val userId = _currentUser.value?.uid
                        if (userId != null) {
                            FirebaseManager.savePostToFirestore(userId, syncedPost)
                        }
                    }

                    // Save used topic in Firebase Firestore
                    val userId = _currentUser.value?.uid
                    if (userId != null) {
                        FirebaseManager.saveUsedTopicToFirestore(userId, postTitle)
                    }

                    delay(1500)
                    onComplete(true)
                } else {
                    val errMsg = response.error?.message ?: "نامعلوم خرابی رونما ہوئی۔"
                    _errorMessage.value = "فیس بک پر پوسٹ کرنے میں ناکامی: $errMsg"
                    _facebookPostStatus.value = "اپلوڈ کرنے میں خرابی آئی۔"
                    onComplete(false)
                }
            } catch (e: Exception) {
                val errMsg = e.localizedMessage ?: e.message ?: "نیٹ ورک کنکشن کی خرابی۔"
                _errorMessage.value = "فیس بک پر پوسٹ کرنے میں ناکامی: $errMsg"
                _facebookPostStatus.value = "نیٹ ورک یا ٹوکن کی خرابی۔"
                onComplete(false)
            } finally {
                _isPostingToFacebook.value = false
            }
        }
    }

    fun syncFacebookCredentials(context: android.content.Context) {
        val userId = _currentUser.value?.uid ?: return
        viewModelScope.launch {
            try {
                val creds = FirebaseManager.fetchUserCredentialsFromFirestore(userId)
                if (creds != null) {
                    val (pageId, token) = creds
                    val prefs = context.getSharedPreferences("fb_prefs", android.content.Context.MODE_PRIVATE)
                    prefs.edit()
                        .putString("page_id_$userId", pageId)
                        .putString("access_token_$userId", token)
                        .putBoolean("saved_$userId", pageId.isNotEmpty() && token.isNotEmpty())
                        .apply()
                }
            } catch (e: Exception) {
                Log.e("PostViewModel", "Error syncing Facebook credentials from cloud: ${e.message}")
            }
        }
    }

    fun saveFacebookCredentials(
        context: android.content.Context,
        pageId: String,
        accessToken: String,
        saveLocal: Boolean,
        onResult: (Boolean) -> Unit
    ) {
        val userId = _currentUser.value?.uid
        if (userId == null) {
            onResult(false)
            return
        }
        viewModelScope.launch {
            try {
                val prefs = context.getSharedPreferences("fb_prefs", android.content.Context.MODE_PRIVATE)
                if (saveLocal) {
                    prefs.edit()
                        .putString("page_id_$userId", pageId.trim())
                        .putString("access_token_$userId", accessToken.trim())
                        .putBoolean("saved_$userId", true)
                        .apply()
                    
                    // Sync with Firestore
                    FirebaseManager.saveUserCredentialsToFirestore(userId, pageId.trim(), accessToken.trim())
                } else {
                    prefs.edit()
                        .remove("page_id_$userId")
                        .remove("access_token_$userId")
                        .remove("saved_$userId")
                        .apply()
                    
                    // Remove from Firestore
                    FirebaseManager.saveUserCredentialsToFirestore(userId, "", "")
                }
                onResult(true)
            } catch (e: Exception) {
                Log.e("PostViewModel", "Error saving FB credentials: ${e.message}")
                onResult(false)
            }
        }
    }

    private suspend fun generateWithModel(apiKey: String, request: GenerateContentRequest, preferredModel: String = "gemini-2.5-flash"): GenerateContentResponse {
        return try {
            RetrofitClient.service.generateContent(preferredModel, apiKey, request)
        } catch (e: Exception) {
            val errorMsg = e.message ?: ""
            if (preferredModel != "gemini-3.5-flash") {
                Log.e("PostViewModel", "Failed to generate content with $preferredModel, falling back to gemini-3.5-flash: $errorMsg")
                RetrofitClient.service.generateContent("gemini-3.5-flash", apiKey, request)
            } else {
                throw e
            }
        }
    }
}

class PostViewModelFactory(private val repository: PostRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PostViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PostViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
